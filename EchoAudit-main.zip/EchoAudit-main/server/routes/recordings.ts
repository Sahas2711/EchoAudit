import { Request, Response } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";

// Create recordings directory if it doesn't exist
const recordingsDir = path.join(process.cwd(), "recordings");
if (!fs.existsSync(recordingsDir)) {
  fs.mkdirSync(recordingsDir, { recursive: true });
  console.log("Created recordings directory:", recordingsDir);
}

// Configure multer for file upload to recordings folder
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, recordingsDir);
  },
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    const originalName = file.originalname || 'recording';
    const extension = path.extname(originalName) || '.webm';
    const filename = `${originalName.replace(extension, '')}_${timestamp}${extension}`;
    cb(null, filename);
  },
});

const upload = multer({ 
  storage,
  fileFilter: (req, file, cb) => {
    // Accept audio files
    if (file.mimetype.startsWith("audio/")) {
      cb(null, true);
    } else {
      cb(new Error("Only audio files are allowed"));
    }
  },
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB limit
  },
});

// Get all recordings from the folder
export const getRecordings = (req: Request, res: Response) => {
  try {
    const files = fs.readdirSync(recordingsDir);
    const recordings = files
      .filter(file => {
        const ext = path.extname(file).toLowerCase();
        return ['.webm', '.mp3', '.wav', '.ogg', '.m4a', '.aac', '.flac'].includes(ext);
      })
      .map(file => {
        const filePath = path.join(recordingsDir, file);
        const stats = fs.statSync(filePath);
        return {
          id: file,
          filename: file,
          size: stats.size,
          type: path.extname(file).toLowerCase(),
          timestamp: stats.mtime,
          path: filePath
        };
      })
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()); // Sort by newest first

    res.json({ recordings });
  } catch (error) {
    console.error("Error reading recordings directory:", error);
    res.status(500).json({ error: "Failed to read recordings" });
  }
};

// Save a recording to the folder
export const saveRecording = (req: Request, res: Response) => {
  upload.single("audio")(req, res, (err) => {
    if (err) {
      return res.status(400).json({ error: err.message });
    }

    if (!req.file) {
      return res.status(400).json({ error: "No audio file provided" });
    }

    try {
      const filePath = req.file.path;
      const stats = fs.statSync(filePath);
      
      const recording = {
        id: req.file.filename,
        filename: req.file.filename,
        size: stats.size,
        type: path.extname(req.file.filename).toLowerCase(),
        timestamp: stats.mtime,
        path: filePath
      };

      console.log(`Recording saved to folder: ${recording.filename} (${recording.size} bytes)`);
      res.json({ success: true, recording });
    } catch (error) {
      console.error("Error saving recording:", error);
      res.status(500).json({ error: "Failed to save recording" });
    }
  });
};

// Download a recording
export const downloadRecording = (req: Request, res: Response) => {
  const { filename } = req.params;
  
  if (!filename) {
    return res.status(400).json({ error: "Filename is required" });
  }

  const filePath = path.join(recordingsDir, filename);
  
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: "Recording not found" });
  }

  try {
    res.download(filePath);
  } catch (error) {
    console.error("Error downloading recording:", error);
    res.status(500).json({ error: "Failed to download recording" });
  }
};

// Delete a recording
export const deleteRecording = (req: Request, res: Response) => {
  const { filename } = req.params;
  
  if (!filename) {
    return res.status(400).json({ error: "Filename is required" });
  }

  const filePath = path.join(recordingsDir, filename);
  
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: "Recording not found" });
  }

  try {
    fs.unlinkSync(filePath);
    console.log(`Recording deleted: ${filename}`);
    res.json({ success: true, message: "Recording deleted successfully" });
  } catch (error) {
    console.error("Error deleting recording:", error);
    res.status(500).json({ error: "Failed to delete recording" });
  }
};

// Get recording statistics
export const getRecordingStats = (req: Request, res: Response) => {
  try {
    const files = fs.readdirSync(recordingsDir);
    const audioFiles = files.filter(file => {
      const ext = path.extname(file).toLowerCase();
      return ['.webm', '.mp3', '.wav', '.ogg', '.m4a', '.aac', '.flac'].includes(ext);
    });

    let totalSize = 0;
    let totalDuration = 0;

    audioFiles.forEach(file => {
      const filePath = path.join(recordingsDir, file);
      const stats = fs.statSync(filePath);
      totalSize += stats.size;
    });

    const stats = {
      count: audioFiles.length,
      totalSize,
      averageSize: audioFiles.length > 0 ? totalSize / audioFiles.length : 0,
      folderPath: recordingsDir
    };

    res.json(stats);
  } catch (error) {
    console.error("Error getting recording stats:", error);
    res.status(500).json({ error: "Failed to get recording statistics" });
  }
};

// Clear all recordings
export const clearAllRecordings = (req: Request, res: Response) => {
  try {
    const files = fs.readdirSync(recordingsDir);
    const audioFiles = files.filter(file => {
      const ext = path.extname(file).toLowerCase();
      return ['.webm', '.mp3', '.wav', '.ogg', '.m4a', '.aac', '.flac'].includes(ext);
    });

    let deletedCount = 0;
    audioFiles.forEach(file => {
      try {
        const filePath = path.join(recordingsDir, file);
        fs.unlinkSync(filePath);
        deletedCount++;
      } catch (error) {
        console.error(`Error deleting file ${file}:`, error);
      }
    });

    console.log(`Cleared ${deletedCount} recordings from folder`);
    res.json({ success: true, deletedCount, message: `Deleted ${deletedCount} recordings` });
  } catch (error) {
    console.error("Error clearing recordings:", error);
    res.status(500).json({ error: "Failed to clear recordings" });
  }
}; 