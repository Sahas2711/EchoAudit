import { Request, Response } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import ffmpeg from "fluent-ffmpeg";
import ffmpegPath from "@ffmpeg-installer/ffmpeg";

// Set FFmpeg path
ffmpeg.setFfmpegPath(ffmpegPath.path);

// Configure multer for file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(process.cwd(), "uploads");
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({ 
  storage,
  fileFilter: (req, file, cb) => {
    // Accept audio files
    if (file.mimetype.startsWith("audio/")) {
      cb(null, true);
    } else {
      cb(new Error("Only audio files are allowed"));
    }
  },
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
});

// Function to convert audio to MP3
function convertToMp3(inputFile: string, outputFile: string): Promise<string> {
  return new Promise((resolve, reject) => {
    ffmpeg(inputFile)
      .toFormat("mp3")
      .audioBitrate(128)
      .on("end", () => {
        console.log("Conversion finished!");
        resolve(outputFile);
      })
      .on("error", (err) => {
        console.error("Error during conversion: ", err);
        reject(err);
      })
      .save(outputFile);
  });
}

// Route to handle audio upload and conversion
export const handleAudioConversion = async (req: Request, res: Response) => {
  try {
    // Use multer to handle file upload
    upload.single("audio")(req, res, async (err) => {
      if (err) {
        return res.status(400).json({ error: err.message });
      }

      if (!req.file) {
        return res.status(400).json({ error: "No audio file provided" });
      }

      const inputFile = req.file.path;
      const outputFileName = `converted-${Date.now()}.mp3`;
      const outputFile = path.join(process.cwd(), "uploads", outputFileName);

      try {
        // Convert the audio file
        const convertedFile = await convertToMp3(inputFile, outputFile);
        
        // Read the converted file
        const audioBuffer = fs.readFileSync(convertedFile);
        
        // Clean up temporary files
        fs.unlinkSync(inputFile);
        fs.unlinkSync(convertedFile);

        // Send the converted audio as response
        res.setHeader("Content-Type", "audio/mpeg");
        res.setHeader("Content-Disposition", `attachment; filename="${outputFileName}"`);
        res.send(audioBuffer);

      } catch (conversionError) {
        // Clean up input file on error
        if (fs.existsSync(inputFile)) {
          fs.unlinkSync(inputFile);
        }
        throw conversionError;
      }
    });
  } catch (error) {
    console.error("Audio conversion error:", error);
    res.status(500).json({ error: "Failed to convert audio file" });
  }
};

// Route to get supported audio formats
export const getSupportedFormats = (req: Request, res: Response) => {
  res.json({
    supportedFormats: [
      "audio/wav",
      "audio/mp3",
      "audio/mpeg",
      "audio/ogg",
      "audio/webm",
      "audio/m4a",
      "audio/aac",
      "audio/flac"
    ]
  });
}; 