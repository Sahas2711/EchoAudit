import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import { handleAudioConversion, getSupportedFormats } from "./routes/audio";
import { 
  getRecordings, 
  saveRecording, 
  downloadRecording, 
  deleteRecording, 
  getRecordingStats, 
  clearAllRecordings 
} from "./routes/recordings";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Example API routes
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  app.get("/api/demo", handleDemo);

  // Audio conversion routes
  app.post("/api/audio/convert", handleAudioConversion);
  app.get("/api/audio/formats", getSupportedFormats);

  // Recording folder routes
  app.get("/api/recordings", getRecordings);
  app.post("/api/recordings/save", saveRecording);
  app.get("/api/recordings/download/:filename", downloadRecording);
  app.delete("/api/recordings/:filename", deleteRecording);
  app.get("/api/recordings/stats", getRecordingStats);
  app.delete("/api/recordings", clearAllRecordings);

  return app;
}
