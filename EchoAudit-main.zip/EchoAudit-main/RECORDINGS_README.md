# Recordings Folder System

This system automatically saves audio recordings to a physical folder on your computer.

## 📁 **Folder Location**

Recordings are saved to: `./recordings/` (in your project root)

## 🚀 **How It Works**

### **1. Automatic Saving**
- Every recording is automatically saved to the server folder
- Files are named with timestamps: `recording_[timestamp].webm`
- Supported formats: WebM, MP3, WAV, OGG, M4A, AAC, FLAC

### **2. Server API Endpoints**

- `GET /api/recordings` - List all recordings
- `POST /api/recordings/save` - Save a new recording
- `GET /api/recordings/download/:filename` - Download a recording
- `DELETE /api/recordings/:filename` - Delete a recording
- `GET /api/recordings/stats` - Get folder statistics
- `DELETE /api/recordings` - Clear all recordings

### **3. File Management**

#### **File Naming Convention**
```
recording_1703123456789.webm
recording_1703123456790.mp3
```

#### **File Information Stored**
- Filename with timestamp
- File size in bytes
- Audio format/type
- Creation timestamp
- Full file path

## 🎯 **Usage**

### **1. Record Audio**
1. Go to `/voice-input` or `/simple-audio-test`
2. Start recording
3. Stop recording
4. **Recording is automatically saved to the folder!**

### **2. Manage Recordings**
1. Go to `/recordings-folder`
2. View all saved recordings
3. Play, download, or delete files
4. See folder statistics

### **3. Direct Folder Access**
- Navigate to `./recordings/` in your file explorer
- All audio files are stored there
- Files persist between server restarts

## 📊 **Features**

### **Automatic Features**
- ✅ Auto-save every recording
- ✅ Unique timestamp-based naming
- ✅ File size and metadata tracking
- ✅ Server-side file management
- ✅ Persistent storage

### **Management Features**
- ✅ View all recordings in web interface
- ✅ Play recordings in browser
- ✅ Download individual files
- ✅ Delete unwanted recordings
- ✅ Clear entire folder
- ✅ Folder statistics

### **Technical Features**
- ✅ 100MB file size limit
- ✅ Audio file type validation
- ✅ Error handling and logging
- ✅ Fallback to local storage
- ✅ Cross-platform compatibility

## 🔧 **Technical Details**

### **Server Implementation**
- **Express.js routes** for file management
- **Multer middleware** for file uploads
- **File system operations** for storage
- **Error handling** for robustness

### **Client Implementation**
- **RecordingManager class** for API communication
- **Automatic upload** after recording
- **Fallback mechanisms** if server unavailable
- **Progress tracking** and error reporting

### **File Storage**
- **Physical folder** on server filesystem
- **Automatic directory creation** if missing
- **File permission handling**
- **Cross-platform path handling**

## 🛠 **Troubleshooting**

### **If recordings aren't saving:**
1. Check server console for errors
2. Verify `./recordings/` folder exists
3. Check file permissions
4. Ensure server is running

### **If folder is empty:**
1. Try recording a new audio file
2. Check browser console for upload errors
3. Verify API endpoints are working
4. Check network connectivity

### **If files are corrupted:**
1. Check audio recording quality
2. Verify microphone permissions
3. Try different audio format
4. Check file size limits

## 📝 **File Structure**

```
recordings/
├── recording_1703123456789.webm
├── recording_1703123456790.mp3
├── recording_1703123456791.wav
└── ...
```

## 🔒 **Security**

- Only audio files are accepted
- File size limits prevent abuse
- Server-side validation
- Safe file naming (no path traversal)

## 📈 **Performance**

- Efficient file I/O operations
- Minimal memory usage
- Fast upload/download
- Optimized for audio files

The recordings folder system provides a robust, automatic way to save and manage your audio recordings with full file system integration! 