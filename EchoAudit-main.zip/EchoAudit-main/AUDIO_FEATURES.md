# Audio Recording and Conversion Features

This document describes the audio recording and conversion functionality integrated into the EchoAudit application.

## Features

### 1. Audio Recording
- **Real-time audio capture** using the Web Audio API
- **High-quality recording** with noise suppression and echo cancellation
- **Visual feedback** with animated waveform during recording
- **Timer display** showing recording duration
- **Pause/Resume** functionality (available in the audio recorder class)

### 2. Audio Conversion
- **Server-side FFmpeg processing** for reliable audio conversion
- **WebM to MP3 conversion** (primary use case)
- **Support for multiple formats** including WAV, OGG, M4A, AAC, FLAC
- **Configurable audio quality** (128kbps MP3 by default)
- **Automatic cleanup** of temporary files

### 3. Audio Playback and Management
- **Built-in audio player** for previewing recordings
- **Download functionality** for both original and converted files
- **Error handling** with user-friendly messages
- **Progress indicators** during conversion

## Technical Implementation

### Frontend (React/TypeScript)
- **WebAudioRecorder class** - Handles browser-based audio recording
- **Audio utilities** - Functions for conversion, playback, and download
- **State management** - Tracks recording status, audio blobs, and conversion progress
- **UI components** - Recording controls, waveform animation, and status display

### Backend (Node.js/Express)
- **FFmpeg integration** - Uses fluent-ffmpeg with @ffmpeg-installer/ffmpeg
- **File upload handling** - Multer middleware for secure file processing
- **Audio conversion API** - POST endpoint for converting uploaded audio
- **Format support API** - GET endpoint for listing supported formats

## API Endpoints

### POST `/api/audio/convert`
Converts uploaded audio file to MP3 format.

**Request:**
- Content-Type: `multipart/form-data`
- Body: Form data with `audio` field containing the audio file

**Response:**
- Content-Type: `audio/mpeg`
- Body: Converted MP3 file as binary data

### GET `/api/audio/formats`
Returns list of supported audio formats.

**Response:**
```json
{
  "supportedFormats": [
    "audio/wav",
    "audio/mp3", 
    "audio/mpeg",
    "audio/ogg",
    "audio/webm",
    "audio/m4a",
    "audio/aac",
    "audio/flac"
  ]
}
```

## Dependencies

### Frontend
- No additional dependencies (uses built-in Web Audio API)

### Backend
- `fluent-ffmpeg` - FFmpeg wrapper for Node.js
- `@ffmpeg-installer/ffmpeg` - FFmpeg binary installer
- `multer` - File upload middleware
- `@types/fluent-ffmpeg` - TypeScript definitions
- `@types/multer` - TypeScript definitions

## Installation

1. Install dependencies:
```bash
npm install fluent-ffmpeg @ffmpeg-installer/ffmpeg multer @types/fluent-ffmpeg @types/multer
```

2. The FFmpeg binary will be automatically installed and configured.

## Usage

### Basic Recording Flow
1. Navigate to the Voice Input page
2. Click "Start Recording" to begin audio capture
3. Speak your task details
4. Click "Stop Recording" when finished
5. Optionally convert to MP3 format
6. Play back or download the audio
7. Continue to AI processing

### Programmatic Usage
```typescript
import { WebAudioRecorder, convertAudioToMp3 } from '../lib/audioUtils';

// Start recording
const recorder = new WebAudioRecorder();
await recorder.start();

// Stop recording and get blob
const audioBlob = await recorder.stop();

// Convert to MP3
const mp3Blob = await convertAudioToMp3(audioBlob);
```

## File Management

- **Temporary files** are stored in the `uploads/` directory
- **Automatic cleanup** removes files after processing
- **Git ignore** prevents temporary files from being committed
- **File size limit** of 50MB per upload

## Error Handling

The system handles various error scenarios:
- **Microphone permissions** - User-friendly error messages
- **Network issues** - Retry mechanisms and fallbacks
- **Conversion failures** - Detailed error logging
- **File format issues** - Validation and format checking

## Browser Compatibility

- **Modern browsers** with Web Audio API support
- **HTTPS required** for microphone access in production
- **Mobile support** for iOS Safari and Android Chrome

## Security Considerations

- **File type validation** - Only audio files accepted
- **File size limits** - Prevents abuse
- **Temporary storage** - Files are not permanently stored
- **CORS configuration** - Proper cross-origin handling

## Performance

- **Streaming uploads** - Large files handled efficiently
- **Background processing** - Conversion doesn't block UI
- **Memory management** - Proper cleanup of audio streams
- **Optimized conversion** - Balanced quality and file size 