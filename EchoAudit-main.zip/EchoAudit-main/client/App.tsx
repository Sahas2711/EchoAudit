import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import RoleSelection from "./pages/RoleSelection";
import ManagerLogin from "./pages/ManagerLogin";
import Dashboard from "./pages/Dashboard";
import ManagerDashboard from "./pages/ManagerDashboard";
import DefineRequiredInfo from "./pages/DefineRequiredInfo";
import StaffLogs from "./pages/StaffLogs";
import StaffManagement from "./pages/StaffManagement";
import VoiceInput from "./pages/VoiceInput";
import AudioDebug from "./pages/AudioDebug";
import SimpleAudioTest from "./pages/SimpleAudioTest";
import RecordingsFolder from "./pages/RecordingsFolder";
import AIProcessing from "./pages/AIProcessing";
import TaskConfirmation from "./pages/TaskConfirmation";
import EditTask from "./pages/EditTask";
import Alerts from "./pages/Alerts";
import Logs from "./pages/Logs";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<RoleSelection />} />
          <Route path="/login" element={<Index />} />
          <Route path="/role-selection" element={<RoleSelection />} />
          <Route path="/RoleSelection" element={<RoleSelection />} />
          <Route path="/manager-login" element={<ManagerLogin />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/manager-dashboard" element={<ManagerDashboard />} />
          <Route path="/ManagerDashboard" element={<ManagerDashboard />} />
          <Route path="/managerdashboard" element={<ManagerDashboard />} />
          <Route
            path="/define-required-info"
            element={<DefineRequiredInfo />}
          />
          <Route path="/staff-logs" element={<StaffLogs />} />
          <Route path="/staff-management" element={<StaffManagement />} />
          <Route path="/voice-input" element={<VoiceInput />} />
          <Route path="/audio-debug" element={<AudioDebug />} />
          <Route path="/simple-audio-test" element={<SimpleAudioTest />} />
          <Route path="/recordings-folder" element={<RecordingsFolder />} />
          <Route path="/ai-processing" element={<AIProcessing />} />
          <Route path="/task-confirmation" element={<TaskConfirmation />} />
          <Route path="/edit-task" element={<EditTask />} />
          <Route path="/alerts" element={<Alerts />} />
          <Route path="/logs" element={<Logs />} />
          <Route path="/settings" element={<Settings />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
