import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Mic, Square, Play, Download, FolderOpen } from "lucide-react";
import { WebAudioRecorder, convertAudioToMp3, playAudioBlob, downloadAudioBlob } from "../lib/audioUtils";
import { checkBrowserSupport, testMicrophoneAccess, getBrowserInfo } from "../lib/audioDebug";
import { recordingManager } from "../lib/recordingManager";

export default function VoiceInput() {
  const navigate = useNavigate();
  const [timer, setTimer] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [mp3Blob, setMp3Blob] = useState<Blob | null>(null);
  const [isConverting, setIsConverting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const audioRecorderRef = useRef<WebAudioRecorder | null>(null);

  // Timer effect
  useEffect(() => {
    const interval = setInterval(() => {
      if (isRecording) {
        setTimer((prev) => prev + 1);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isRecording]);

  // Initialize audio recorder and check browser support
  useEffect(() => {
    audioRecorderRef.current = new WebAudioRecorder();
    
    // Check browser support
    const runBrowserCheck = () => {
      const support = checkBrowserSupport();
      console.log("Initial browser support check:", support);
      
      if (support.errorMessage) {
        setError(`Browser compatibility issue: ${support.errorMessage}`);
      } else {
        console.log("Browser supports audio recording");
      }
    };
    
    runBrowserCheck();
    
    return () => {
      if (audioRecorderRef.current) {
        audioRecorderRef.current.stop().catch(console.error);
      }
    };
  }, []);

  // Format timer to MM:SS
  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleStartRecording = async () => {
    try {
      setError(null);
      await audioRecorderRef.current?.start();
      setIsRecording(true);
      setIsListening(true);
      setTimer(0);
    } catch (err) {
      setError("Failed to start recording. Please check microphone permissions.");
      console.error("Recording error:", err);
    }
  };

  const handleStopRecording = async () => {
    try {
      if (audioRecorderRef.current) {
        const blob = await audioRecorderRef.current.stop();
        setAudioBlob(blob);
        setIsRecording(false);
        setIsListening(false);
        
        // Automatically save the recording
        try {
          const savedRecording = await recordingManager.saveRecording(blob);
          console.log("Recording saved:", savedRecording.filename);
        } catch (saveError) {
          console.warn("Failed to save recording:", saveError);
          // Don't show error to user as recording still works
        }
      }
    } catch (err) {
      setError("Failed to stop recording.");
      console.error("Stop recording error:", err);
    }
  };

  const handleConvertToMp3 = async () => {
    if (!audioBlob) return;
    
    try {
      setIsConverting(true);
      setError(null);
      const mp3Blob = await convertAudioToMp3(audioBlob);
      setMp3Blob(mp3Blob);
    } catch (err) {
      setError("Failed to convert audio to MP3.");
      console.error("Conversion error:", err);
    } finally {
      setIsConverting(false);
    }
  };

  const handlePlayAudio = async () => {
    const blobToPlay = mp3Blob || audioBlob;
    if (!blobToPlay) return;
    
    try {
      await playAudioBlob(blobToPlay);
    } catch (err) {
      setError("Failed to play audio.");
      console.error("Play error:", err);
    }
  };

  const handleDownload = () => {
    const blobToDownload = mp3Blob || audioBlob;
    if (!blobToDownload) return;
    
    const filename = mp3Blob ? "recording.mp3" : "recording.webm";
    downloadAudioBlob(blobToDownload, filename);
  };

  const handleCancel = () => {
    setIsRecording(false);
    setIsListening(false);
    setAudioBlob(null);
    setMp3Blob(null);
    setError(null);
    setTimer(0);
    navigate("/dashboard");
  };

  const handleContinue = () => {
    // Navigate to AI processing with the audio data
    navigate("/ai-processing");
  };

  const handleTestMicrophone = async () => {
    try {
      setError(null);
      console.log("Running comprehensive audio diagnostics...");
      
      // Check browser support
      const support = checkBrowserSupport();
      console.log("Browser support:", support);
      
      if (support.errorMessage) {
        setError(`❌ Browser issue: ${support.errorMessage}`);
        return;
      }
      
      // Test microphone access
      const micTest = await testMicrophoneAccess();
      console.log("Microphone test:", micTest);
      
      if (!micTest.success) {
        setError(`❌ Microphone error: ${micTest.error}`);
        return;
      }
      
      const deviceCount = micTest.deviceInfo?.length || 0;
      const browserInfo = getBrowserInfo();
      
      setError(`✅ Success! Found ${deviceCount} audio device(s). ${browserInfo}. Supported formats: ${support.supportedMimeTypes.join(', ')}`);
      
    } catch (err) {
      console.error("Diagnostic test failed:", err);
      setError(`❌ Test failed: ${(err as Error).message}`);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden max-w-md mx-auto bg-gradient-to-b from-royal-blue to-midnight-green">
      {/* 1️⃣ Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-royal-blue to-midnight-green"></div>

      {/* 2️⃣ Top Section - Timer */}
      <div className="relative z-10 pt-12 pr-6 flex justify-end">
        <div className="bg-gold rounded-full px-4 py-2 shadow-lg">
          <span className="text-royal-blue font-bold text-sm">
            {formatTimer(timer)}
          </span>
        </div>
      </div>

      {/* 3️⃣ Center Section - Waveform Animation */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-8 py-16">
        {/* Background Mic Icon */}
        <div className="absolute inset-0 flex items-center justify-center opacity-10">
          <Mic className="w-64 h-64 text-platinum" />
        </div>

        {/* Error Display */}
        {error && (
          <div className={`absolute top-4 left-4 right-4 p-3 rounded-lg text-sm ${
            error.includes("✅") 
              ? "bg-green-500 text-white" 
              : "bg-red-500 text-white"
          }`}>
            {error}
          </div>
        )}

        {/* Test Microphone Button */}
        {!isRecording && !audioBlob && (
          <div className="absolute top-20 left-4 right-4 space-y-2">
            <button
              onClick={handleTestMicrophone}
              className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg text-sm hover:bg-blue-600 transition-colors"
            >
              Test Microphone & Browser Support
            </button>
            <button
              onClick={() => navigate("/recordings-folder")}
              className="w-full bg-green-500 text-white py-2 px-4 rounded-lg text-sm hover:bg-green-600 transition-colors flex items-center justify-center space-x-2"
            >
              <FolderOpen className="w-4 h-4" />
              <span>View Recordings Folder</span>
            </button>
          </div>
        )}

        {/* Animated Waveform - only show when recording */}
        {isRecording && (
          <div className="relative mb-8">
            {/* Glow effect */}
            <div className="absolute inset-0 bg-white rounded-full blur-xl opacity-20"></div>

            {/* Waveform bars */}
            <div className="relative flex items-center justify-center space-x-1">
              {Array.from({ length: 12 }).map((_, i) => (
                <div
                  key={i}
                  className="bg-gold rounded-full animate-pulse"
                  style={{
                    width: "4px",
                    height: `${20 + Math.sin(Date.now() * 0.01 + i) * 15}px`,
                    animationDelay: `${i * 0.1}s`,
                    animationDuration: `${0.8 + (i % 3) * 0.2}s`,
                  }}
                ></div>
              ))}
            </div>
          </div>
        )}

        {/* Status Text */}
        <div className="text-center mb-8">
          {!audioBlob ? (
            <>
              <h2 className="text-white text-lg font-medium mb-1">
                {isRecording ? "Recording..." : "Ready to Record"}
              </h2>
              <p className="text-platinum text-sm">
                {isRecording ? "Speak your task details" : "Click the mic to start recording"}
              </p>
            </>
          ) : (
            <>
              <h2 className="text-white text-lg font-medium mb-1">Recording Complete!</h2>
              <p className="text-platinum text-sm">
                {mp3Blob ? "Audio converted to MP3" : "Audio ready for conversion"}
              </p>
              <p className="text-platinum text-xs mt-2">
                Size: {(audioBlob.size / 1024).toFixed(1)} KB | Type: {audioBlob.type}
              </p>
            </>
          )}
        </div>

        {/* Audio Controls */}
        {audioBlob && (
          <div className="flex gap-4 mb-8">
            <button
              onClick={handlePlayAudio}
              className="bg-gold text-royal-blue p-3 rounded-full hover:bg-yellow-400 transition-colors"
              title="Play Audio"
            >
              <Play className="w-6 h-6" />
            </button>
            
            {!mp3Blob && (
              <button
                onClick={handleConvertToMp3}
                disabled={isConverting}
                className="bg-gold text-royal-blue p-3 rounded-full hover:bg-yellow-400 transition-colors disabled:opacity-50"
                title="Convert to MP3"
              >
                {isConverting ? (
                  <div className="w-6 h-6 border-2 border-royal-blue border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <span className="text-sm font-bold">MP3</span>
                )}
              </button>
            )}
            
            <button
              onClick={handleDownload}
              className="bg-gold text-royal-blue p-3 rounded-full hover:bg-yellow-400 transition-colors"
              title="Download Audio"
            >
              <Download className="w-6 h-6" />
            </button>
          </div>
        )}

        {/* Pulse animation around center */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-48 h-48 border border-gold rounded-full animate-ping opacity-20"></div>
          <div
            className="absolute w-32 h-32 border border-gold rounded-full animate-ping opacity-30"
            style={{ animationDelay: "0.5s" }}
          ></div>
        </div>
      </div>

      {/* 4️⃣ Bottom Section - Controls */}
      <div className="relative z-10 px-8 pb-8 space-y-4">
        {/* Recording Controls */}
        {!audioBlob ? (
          <div className="flex gap-4">
            {!isRecording ? (
              <button
                onClick={handleStartRecording}
                className="flex-1 bg-gold text-royal-blue font-bold py-4 px-6 rounded-3xl shadow-lg hover:bg-yellow-400 transition-all duration-200 transform hover:scale-105 flex items-center justify-center gap-2"
              >
                <Mic className="w-6 h-6" />
                Start Recording
              </button>
            ) : (
              <button
                onClick={handleStopRecording}
                className="flex-1 bg-red-500 text-white font-bold py-4 px-6 rounded-3xl shadow-lg hover:bg-red-600 transition-all duration-200 transform hover:scale-105 flex items-center justify-center gap-2"
              >
                <Square className="w-6 h-6" />
                Stop Recording
              </button>
            )}
            
            <button
              onClick={handleCancel}
              className="bg-gray-500 text-white font-bold py-4 px-6 rounded-3xl shadow-lg hover:bg-gray-600 transition-all duration-200 transform hover:scale-105"
            >
              Cancel
            </button>
          </div>
        ) : (
          <div className="flex gap-4">
            <button
              onClick={handleContinue}
              className="flex-1 bg-green-500 text-white font-bold py-4 px-6 rounded-3xl shadow-lg hover:bg-green-600 transition-all duration-200 transform hover:scale-105"
            >
              Continue to AI Processing
            </button>
            
            <button
              onClick={handleCancel}
              className="bg-gray-500 text-white font-bold py-4 px-6 rounded-3xl shadow-lg hover:bg-gray-600 transition-all duration-200 transform hover:scale-105"
            >
              Record Again
            </button>
          </div>
        )}
      </div>

      {/* Additional animated elements */}
      <div
        className="absolute top-1/4 left-4 w-2 h-2 bg-gold rounded-full animate-bounce opacity-60"
        style={{ animationDelay: "1s" }}
      ></div>
      <div
        className="absolute top-1/3 right-8 w-1 h-1 bg-platinum rounded-full animate-bounce opacity-40"
        style={{ animationDelay: "2s" }}
      ></div>
      <div
        className="absolute bottom-1/4 left-12 w-1.5 h-1.5 bg-gold rounded-full animate-bounce opacity-50"
        style={{ animationDelay: "1.5s" }}
      ></div>

      {/* CSS for enhanced waveform animation */}
      <style>{`
        @keyframes waveform {
          0%, 100% { height: 20px; }
          50% { height: 40px; }
        }
        
        .waveform-bar {
          animation: waveform 0.8s ease-in-out infinite;
        }
        
        .waveform-bar:nth-child(2) { animation-delay: 0.1s; }
        .waveform-bar:nth-child(3) { animation-delay: 0.2s; }
        .waveform-bar:nth-child(4) { animation-delay: 0.3s; }
        .waveform-bar:nth-child(5) { animation-delay: 0.4s; }
        .waveform-bar:nth-child(6) { animation-delay: 0.5s; }
        .waveform-bar:nth-child(7) { animation-delay: 0.4s; }
        .waveform-bar:nth-child(8) { animation-delay: 0.3s; }
        .waveform-bar:nth-child(9) { animation-delay: 0.2s; }
        .waveform-bar:nth-child(10) { animation-delay: 0.1s; }
        .waveform-bar:nth-child(11) { animation-delay: 0.2s; }
        .waveform-bar:nth-child(12) { animation-delay: 0.3s; }
      `}</style>
    </div>
  );
}
