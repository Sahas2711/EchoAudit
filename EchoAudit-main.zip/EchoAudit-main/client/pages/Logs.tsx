import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Filter,
  Search,
  ChevronDown,
  FileText,
  Download,
} from "lucide-react";

interface LogEntry {
  id: string;
  date: string;
  time: string;
  task: string;
  category: string;
  status: "completed" | "pending" | "alerted";
  location?: string;
  assignedTo?: string;
}

export default function Logs() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [dateFilter, setDateFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");

  const [logs] = useState<LogEntry[]>([
    {
      id: "1",
      date: "Aug 13, 2025",
      time: "14:35",
      task: "Check oxygen supply in Ward B",
      category: "Healthcare",
      status: "completed",
      location: "Ward B - Room 205",
      assignedTo: "Dr. Smith",
    },
    {
      id: "2",
      date: "Aug 13, 2025",
      time: "13:20",
      task: "Temperature monitoring - ICU",
      category: "Healthcare",
      status: "pending",
      location: "ICU",
      assignedTo: "Nurse Johnson",
    },
    {
      id: "3",
      date: "Aug 13, 2025",
      time: "12:45",
      task: "Equipment maintenance check",
      category: "Maintenance",
      status: "alerted",
      location: "Operating Room 3",
      assignedTo: "Tech Team",
    },
    {
      id: "4",
      date: "Aug 13, 2025",
      time: "11:30",
      task: "Daily safety inspection",
      category: "Safety",
      status: "completed",
      location: "Manufacturing Floor A",
      assignedTo: "Safety Officer",
    },
    {
      id: "5",
      date: "Aug 12, 2025",
      time: "16:20",
      task: "Fire safety drill completion",
      category: "Safety",
      status: "completed",
      location: "Building B",
      assignedTo: "Emergency Team",
    },
    {
      id: "6",
      date: "Aug 12, 2025",
      time: "15:10",
      task: "Ventilation system check",
      category: "Maintenance",
      status: "pending",
      location: "HVAC Room",
      assignedTo: "Maintenance",
    },
  ]);

  const handleBack = () => {
    navigate("/dashboard");
  };

  const handleExportPDF = () => {
    console.log("Exporting to PDF...");
    // In a real app, this would trigger PDF export
  };

  const handleExportExcel = () => {
    console.log("Exporting to Excel...");
    // In a real app, this would trigger Excel export
  };

  // Filter logs based on search and filters
  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.task.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.location?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.assignedTo?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      categoryFilter === "all" ||
      log.category.toLowerCase() === categoryFilter.toLowerCase();

    const matchesDate =
      dateFilter === "all" ||
      (dateFilter === "today" && log.date.includes("Aug 13")) ||
      (dateFilter === "yesterday" && log.date.includes("Aug 12"));

    return matchesSearch && matchesCategory && matchesDate;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <span className="bg-platinum text-green-600 text-xs font-medium px-2 py-1 rounded-full">
            Completed
          </span>
        );
      case "pending":
        return (
          <span className="bg-white border border-gold text-gold text-xs font-medium px-2 py-1 rounded-full">
            Pending
          </span>
        );
      case "alerted":
        return (
          <span className="bg-platinum text-red-500 text-xs font-medium px-2 py-1 rounded-full">
            Alerted
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto">
      {/* 1️⃣ Header */}
      <header className="bg-royal-blue px-4 py-3 flex items-center justify-between">
        {/* Left: Back arrow */}
        <button
          onClick={handleBack}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>

        {/* Center: Title */}
        <h1 className="text-white text-lg font-bold">Logs / History</h1>

        {/* Right: Filter icon */}
        <button className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors">
          <Filter className="w-5 h-5 text-gold" />
        </button>
      </header>

      {/* Content */}
      <div className="flex-1 px-4 py-4 space-y-4">
        {/* 2️⃣ Search Bar */}
        <div className="bg-white border border-platinum rounded-lg px-3 py-3 flex items-center">
          <Search className="w-5 h-5 text-midnight-green mr-3" />
          <input
            type="text"
            placeholder="Search logs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 text-midnight-green placeholder-platinum text-sm bg-transparent outline-none"
          />
        </div>

        {/* 3️⃣ Filters Row */}
        <div className="grid grid-cols-2 gap-3">
          <div className="relative">
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="w-full bg-white border border-platinum text-gold text-sm font-medium py-3 px-3 rounded-lg appearance-none cursor-pointer"
            >
              <option value="all">All Dates</option>
              <option value="today">Today</option>
              <option value="yesterday">Yesterday</option>
              <option value="week">This Week</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-midnight-green pointer-events-none" />
          </div>

          <div className="relative">
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full bg-white border border-platinum text-gold text-sm font-medium py-3 px-3 rounded-lg appearance-none cursor-pointer"
            >
              <option value="all">All Categories</option>
              <option value="healthcare">Healthcare</option>
              <option value="safety">Safety</option>
              <option value="maintenance">Maintenance</option>
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-midnight-green pointer-events-none" />
          </div>
        </div>

        {/* 4️⃣ Logs Table (Mobile-friendly) */}
        {filteredLogs.length > 0 ? (
          <div className="space-y-3">
            {filteredLogs.map((log) => (
              <div
                key={log.id}
                className="bg-white rounded-lg p-4 shadow-sm border border-platinum"
              >
                {/* First line: Date and Status */}
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gold text-sm font-bold">
                    {log.date}
                  </span>
                  {getStatusBadge(log.status)}
                </div>

                {/* Second line: Task */}
                <div className="mb-2">
                  <p className="text-midnight-green text-sm font-medium leading-relaxed">
                    {log.task}
                  </p>
                </div>

                {/* Third line: Category and additional details */}
                <div className="flex items-center justify-between text-xs">
                  <span className="text-platinum">{log.category}</span>
                  <span className="text-platinum">{log.time}</span>
                </div>

                {/* Additional details if available */}
                {(log.location || log.assignedTo) && (
                  <div className="mt-2 pt-2 border-t border-platinum space-y-1">
                    {log.location && (
                      <div className="flex items-center text-xs">
                        <span className="text-platinum mr-2">📍</span>
                        <span className="text-platinum">{log.location}</span>
                      </div>
                    )}
                    {log.assignedTo && (
                      <div className="flex items-center text-xs">
                        <span className="text-platinum mr-2">👤</span>
                        <span className="text-platinum">
                          Assigned to {log.assignedTo}
                        </span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          /* 6️⃣ Empty State */
          <div className="flex-1 flex flex-col items-center justify-center py-12">
            <div className="w-16 h-16 bg-platinum rounded-full flex items-center justify-center mb-4">
              <FileText className="w-8 h-8 text-midnight-green" />
            </div>
            <h3 className="text-midnight-green text-lg font-medium mb-2">
              No logs found
            </h3>
            <p className="text-platinum text-sm text-center">
              Adjust filters or search again
            </p>
          </div>
        )}
      </div>

      {/* Results summary */}
      {filteredLogs.length > 0 && (
        <div className="px-4 py-3 bg-white border-t border-platinum">
          <div className="flex justify-between items-center text-xs">
            <span className="text-midnight-green">
              Showing {filteredLogs.length} of {logs.length} logs
            </span>
            <div className="flex items-center space-x-3">
              <div className="flex items-center">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                <span className="text-platinum">
                  {filteredLogs.filter((l) => l.status === "completed").length}{" "}
                  Completed
                </span>
              </div>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-gold rounded-full mr-1"></div>
                <span className="text-platinum">
                  {filteredLogs.filter((l) => l.status === "pending").length}{" "}
                  Pending
                </span>
              </div>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-red-500 rounded-full mr-1"></div>
                <span className="text-platinum">
                  {filteredLogs.filter((l) => l.status === "alerted").length}{" "}
                  Alerted
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5️⃣ Export Buttons */}
      <div className="px-4 py-4 bg-white border-t border-platinum space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={handleExportPDF}
            className="bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors flex items-center justify-center"
          >
            <Download className="w-4 h-4 mr-2" />
            Export PDF
          </button>

          <button
            onClick={handleExportExcel}
            className="bg-white border border-platinum text-midnight-green font-medium py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center"
          >
            <Download className="w-4 h-4 mr-2" />
            Export Excel
          </button>
        </div>
      </div>
    </div>
  );
}
