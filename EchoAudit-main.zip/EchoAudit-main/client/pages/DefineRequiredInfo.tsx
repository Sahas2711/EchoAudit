import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Save,
  Plus,
  Home,
  Bell,
  FileText,
  User,
  X,
  Info,
  Check,
  Lock,
} from "lucide-react";

interface RequiredField {
  id: string;
  label: string;
  icon?: string;
  enabled: boolean;
  isCustom?: boolean;
  isLocked?: boolean;
  fieldType?: "text" | "number" | "date" | "dropdown";
}

export default function DefineRequiredInfo() {
  const navigate = useNavigate();

  const [fields, setFields] = useState<RequiredField[]>([
    {
      id: "staffId",
      label: "Staff ID",
      icon: "🆔",
      enabled: true,
      isLocked: true,
    },
    { id: "checkInTime", label: "Check-in Time", icon: "⏰", enabled: true },
    { id: "taskCompleted", label: "Task Completed", icon: "📝", enabled: true },
    {
      id: "dailyReportNotes",
      label: "Daily Report Notes",
      icon: "📊",
      enabled: false,
    },
    {
      id: "issuesAlerts",
      label: "Issues / Alerts Raised",
      icon: "⚠️",
      enabled: true,
    },
    { id: "location", label: "Location", icon: "📍", enabled: true },
    {
      id: "patientClientName",
      label: "Patient / Client Name",
      icon: "🏥",
      enabled: false,
    },
  ]);

  const [showCustomFieldModal, setShowCustomFieldModal] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);
  const [customFieldName, setCustomFieldName] = useState("");
  const [customFieldType, setCustomFieldType] = useState<
    "text" | "number" | "date" | "dropdown"
  >("text");
  const [industryTemplate] = useState("healthcare"); // This would come from user settings

  const handleBack = () => {
    navigate("/manager-dashboard");
  };

  const handleSave = () => {
    console.log(
      "Saving required fields:",
      fields.filter((f) => f.enabled),
    );
    // In a real app, this would save to the backend
    navigate("/manager-dashboard");
  };

  const handleCancel = () => {
    navigate("/manager-dashboard");
  };

  const toggleField = (fieldId: string) => {
    setFields((prev) =>
      prev.map((field) =>
        field.id === fieldId && !field.isLocked
          ? { ...field, enabled: !field.enabled }
          : field,
      ),
    );
  };

  const addCustomField = () => {
    if (customFieldName.trim()) {
      const newField: RequiredField = {
        id: `custom_${Date.now()}`,
        label: customFieldName,
        icon: "📋",
        enabled: true,
        isCustom: true,
        fieldType: customFieldType,
      };
      setFields((prev) => [...prev, newField]);
      setCustomFieldName("");
      setCustomFieldType("text");
      setShowCustomFieldModal(false);
    }
  };

  const removeCustomField = (fieldId: string) => {
    setFields((prev) => prev.filter((field) => field.id !== fieldId));
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto">
      {/* 1️⃣ Header */}
      <header className="bg-royal-blue px-4 py-3 flex items-center justify-between">
        {/* Left: Back Arrow */}
        <button
          onClick={handleBack}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>

        {/* Center: Title */}
        <h1 className="text-white text-xl font-bold">Define Required Info</h1>

        {/* Right: Save Icon */}
        <button
          onClick={handleSave}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <Save className="w-5 h-5 text-gold" />
        </button>
      </header>

      {/* Content */}
      <div className="flex-1 px-4 py-6 space-y-6">
        {/* 2️⃣ Instruction Text */}
        <div className="bg-white rounded-lg p-4 shadow-sm border border-platinum">
          <div className="flex items-start">
            <div className="flex-1">
              <p className="text-royal-blue font-medium text-sm leading-relaxed">
                Select the fields staff must fill in every log. Your selection
                will be enforced for all new entries.
              </p>
            </div>
            <div className="relative ml-3">
              <button
                onMouseEnter={() => setShowTooltip(true)}
                onMouseLeave={() => setShowTooltip(false)}
                onClick={() => setShowTooltip(!showTooltip)}
                className="text-platinum hover:text-midnight-green transition-colors"
              >
                <Info className="w-4 h-4" />
              </button>

              {showTooltip && (
                <div className="absolute bottom-full right-0 mb-2 w-48 bg-midnight-green text-white text-xs rounded-lg p-2 shadow-lg z-10">
                  Missing fields will automatically be flagged in logs.
                  <div className="absolute top-full right-4 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-midnight-green"></div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* 3️⃣ Input Section (Professional Toggle Cards) */}
        <div className="space-y-3">
          {fields
            .filter(
              (field) =>
                !field.id.includes("patient") ||
                industryTemplate === "healthcare",
            )
            .map((field) => (
              <div
                key={field.id}
                className="bg-white border border-platinum rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center flex-1">
                    <span className="text-lg mr-3">{field.icon}</span>
                    <div className="flex-1">
                      <div className="flex items-center">
                        <span className="text-royal-blue font-bold text-sm">
                          {field.label}
                        </span>
                        {field.isLocked && (
                          <Lock className="w-3 h-3 text-platinum ml-2" />
                        )}
                        {field.isCustom && (
                          <button
                            onClick={() => removeCustomField(field.id)}
                            className="ml-2 text-red-500 hover:text-red-700 transition-colors"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                      {field.isLocked && (
                        <span className="text-platinum text-xs">
                          Required field
                        </span>
                      )}
                      {field.fieldType && field.isCustom && (
                        <span className="text-platinum text-xs">
                          Type: {field.fieldType}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Professional Toggle Switch */}
                  <button
                    onClick={() => toggleField(field.id)}
                    disabled={field.isLocked}
                    className={`relative inline-flex h-7 w-12 items-center rounded-full transition-all duration-200 ${
                      field.enabled ? "bg-gold shadow-md" : "bg-platinum"
                    } ${field.isLocked ? "opacity-70 cursor-not-allowed" : "hover:shadow-lg"}`}
                  >
                    <span
                      className={`inline-flex h-5 w-5 items-center justify-center transform rounded-full bg-white transition-all duration-200 shadow-sm ${
                        field.enabled ? "translate-x-6" : "translate-x-1"
                      }`}
                    >
                      {field.enabled && <Check className="w-3 h-3 text-gold" />}
                    </span>
                  </button>
                </div>
              </div>
            ))}
        </div>

        {/* 4️⃣ Custom Field Option */}
        <button
          onClick={() => setShowCustomFieldModal(true)}
          className="w-full bg-white border-2 border-dashed border-platinum rounded-lg p-6 shadow-sm hover:bg-gray-50 transition-colors"
        >
          <div className="flex items-center justify-center">
            <Plus className="w-5 h-5 text-gold mr-2" />
            <span className="text-gold font-bold text-base">
              Add Custom Field
            </span>
          </div>
        </button>
      </div>

      {/* 5️⃣ Action Buttons (Bottom Fixed) */}
      <div className="px-4 py-4 bg-white border-t border-platinum space-y-3">
        {/* Save Button */}
        <button
          onClick={handleSave}
          className="w-full bg-gold text-royal-blue font-bold py-4 px-6 rounded-lg hover:bg-yellow-400 transition-colors duration-200 shadow-sm"
        >
          Save Requirements
        </button>

        {/* Cancel Button */}
        <button
          onClick={handleCancel}
          className="w-full bg-white border border-platinum text-royal-blue font-medium py-4 px-6 rounded-lg hover:bg-gray-50 transition-colors duration-200"
        >
          Cancel
        </button>
      </div>

      {/* 6️⃣ Footer Navigation */}
      <nav className="bg-royal-blue px-4 py-3">
        <div className="grid grid-cols-4 gap-1">
          <button
            onClick={() => navigate("/manager-dashboard")}
            className="flex flex-col items-center py-2"
          >
            <Home className="w-5 h-5 text-gold mb-1" />
            <span className="text-gold text-xs font-medium">Dashboard</span>
          </button>

          <button
            onClick={() => navigate("/alerts")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <Bell className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Alerts</span>
          </button>

          <button
            onClick={() => navigate("/logs")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <FileText className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Logs</span>
          </button>

          <button
            onClick={() => navigate("/settings")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <User className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Profile</span>
          </button>
        </div>
      </nav>

      {/* Enhanced Custom Field Modal */}
      {showCustomFieldModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <h3 className="text-royal-blue font-bold text-lg mb-4">
              Add Custom Field
            </h3>

            <div className="space-y-4">
              <div>
                <label className="text-midnight-green text-sm font-medium mb-2 block">
                  Field Name
                </label>
                <input
                  type="text"
                  value={customFieldName}
                  onChange={(e) => setCustomFieldName(e.target.value)}
                  placeholder="Enter field name..."
                  className="w-full px-3 py-3 border border-platinum rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent text-midnight-green"
                  autoFocus
                />
              </div>

              <div>
                <label className="text-midnight-green text-sm font-medium mb-2 block">
                  Field Type
                </label>
                <select
                  value={customFieldType}
                  onChange={(e) => setCustomFieldType(e.target.value as any)}
                  className="w-full px-3 py-3 border border-platinum rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent text-midnight-green"
                >
                  <option value="text">Text</option>
                  <option value="number">Number</option>
                  <option value="date">Date</option>
                  <option value="dropdown">Dropdown</option>
                </select>
              </div>
            </div>

            <div className="flex space-x-3 mt-6">
              <button
                onClick={addCustomField}
                disabled={!customFieldName.trim()}
                className="flex-1 bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Add Field
              </button>

              <button
                onClick={() => {
                  setShowCustomFieldModal(false);
                  setCustomFieldName("");
                  setCustomFieldType("text");
                }}
                className="flex-1 bg-white border border-platinum text-midnight-green font-medium py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
