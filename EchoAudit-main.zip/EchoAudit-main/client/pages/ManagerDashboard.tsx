import { useNavigate } from "react-router-dom";
import {
  Settings,
  Users,
  FileText,
  AlertTriangle,
  Building,
  Home,
  Bell,
  User,
  PinIcon as Pin,
} from "lucide-react";

export default function ManagerDashboard() {
  const navigate = useNavigate();

  const handleSettings = () => {
    navigate("/settings");
  };

  const handleDefineRequiredInfo = () => {
    navigate("/define-required-info");
  };

  const handleViewAlerts = () => {
    navigate("/alerts");
  };

  const handleViewLogs = () => {
    navigate("/staff-logs");
  };

  const handleStaffManagement = () => {
    navigate("/staff-management");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto">
      {/* 1. Header */}
      <header className="bg-royal-blue px-4 py-3 flex items-center justify-between">
        {/* Center: Title */}
        <div className="flex-1 text-center">
          <h1 className="text-white text-lg font-bold">Manager Dashboard</h1>
        </div>

        {/* Right: Settings icon */}
        <button
          onClick={handleSettings}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <Settings className="w-5 h-5 text-gold" />
        </button>
      </header>

      {/* Content */}
      <div className="flex-1 px-4 py-6 space-y-6">
        {/* 2. Overview Cards (2x2 Grid) */}
        <div className="grid grid-cols-2 gap-4">
          {/* Active Staff Card */}
          <div className="bg-white border border-platinum rounded-lg p-4 shadow-sm">
            <div className="flex items-center mb-2">
              <Users className="w-5 h-5 text-royal-blue mr-2" />
              <span className="text-midnight-green text-sm font-medium">
                Active Staff
              </span>
            </div>
            <div className="text-2xl font-bold text-midnight-green">12</div>
          </div>

          {/* Logs Today Card */}
          <div className="bg-white border border-platinum rounded-lg p-4 shadow-sm">
            <div className="flex items-center mb-2">
              <FileText className="w-5 h-5 text-royal-blue mr-2" />
              <span className="text-midnight-green text-sm font-medium">
                Logs Today
              </span>
            </div>
            <div className="text-2xl font-bold text-midnight-green">45</div>
          </div>

          {/* Alerts Raised Card */}
          <div className="bg-white border border-platinum rounded-lg p-4 shadow-sm">
            <div className="flex items-center mb-2">
              <AlertTriangle className="w-5 h-5 text-royal-blue mr-2" />
              <span className="text-midnight-green text-sm font-medium">
                Alerts Raised
              </span>
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs text-midnight-green">Critical:</span>
                <span className="text-sm font-bold text-gold">3</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-midnight-green">Resolved:</span>
                <span className="text-sm font-bold text-royal-blue">7</span>
              </div>
            </div>
          </div>

          {/* Industry Template Card */}
          <div className="bg-white border border-platinum rounded-lg p-4 shadow-sm">
            <div className="flex items-center mb-2">
              <Building className="w-5 h-5 text-royal-blue mr-2" />
              <span className="text-midnight-green text-sm font-medium">
                Industry Template
              </span>
            </div>
            <div className="text-sm font-bold text-midnight-green">
              Healthcare
            </div>
          </div>
        </div>

        {/* 3. Quick Actions (Row of Buttons) */}
        <div className="space-y-3">
          <h3 className="text-midnight-green font-medium text-base">
            Quick Actions
          </h3>

          <div className="space-y-3">
            {/* Define Required Info Button */}
            <button
              onClick={handleDefineRequiredInfo}
              className="w-full bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors duration-200 shadow-sm flex items-center justify-center"
            >
              <Pin className="w-5 h-5 mr-2" />
              Define Required Info
            </button>

            {/* View Alerts Button */}
            <button
              onClick={handleViewAlerts}
              className="w-full bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors duration-200 shadow-sm flex items-center justify-center"
            >
              <AlertTriangle className="w-5 h-5 mr-2" />
              View Alerts
            </button>

            {/* View Logs Button */}
            <button
              onClick={handleViewLogs}
              className="w-full bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors duration-200 shadow-sm flex items-center justify-center"
            >
              <FileText className="w-5 h-5 mr-2" />
              View Logs
            </button>

            {/* Staff Management Button */}
            <button
              onClick={handleStaffManagement}
              className="w-full bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors duration-200 shadow-sm flex items-center justify-center"
            >
              <Users className="w-5 h-5 mr-2" />
              Staff Management
            </button>
          </div>
        </div>

        {/* Recent Activity Summary */}
        <div className="bg-white border border-platinum rounded-lg p-4 shadow-sm">
          <h4 className="text-midnight-green font-medium text-sm mb-3">
            Recent Activity
          </h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-midnight-green">Last staff login:</span>
              <span className="text-platinum">2 mins ago</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-midnight-green">New logs received:</span>
              <span className="text-platinum">5 mins ago</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-midnight-green">Alert resolved:</span>
              <span className="text-platinum">15 mins ago</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Footer Navigation */}
      <nav className="bg-midnight-green px-4 py-3">
        <div className="grid grid-cols-4 gap-1">
          {/* Dashboard - Active */}
          <button className="flex flex-col items-center py-2">
            <Home className="w-5 h-5 text-gold mb-1" />
            <span className="text-gold text-xs font-medium">Dashboard</span>
          </button>

          {/* Alerts */}
          <button
            onClick={handleViewAlerts}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <Bell className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Alerts</span>
          </button>

          {/* Logs */}
          <button
            onClick={handleViewLogs}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <FileText className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Logs</span>
          </button>

          {/* Profile */}
          <button
            onClick={handleSettings}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <User className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Profile</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
