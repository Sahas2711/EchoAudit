import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Info,
  AlertTriangle,
  Clock,
  Tag,
  User,
  MapPin,
} from "lucide-react";

export default function TaskConfirmation() {
  const navigate = useNavigate();
  const [taskData] = useState({
    taskName: "Check oxygen supply in Ward B",
    time: "14:35",
    category: "Healthcare",
    location: "Ward B - Room 205",
    assignedTo: "",
    priority: "",
    patientId: "",
    missingFields: ["Patient ID", "Priority Level", "Assigned Staff"],
  });

  const hasCriticalMissing = taskData.missingFields.includes("Patient ID");
  const hasWarnings = taskData.missingFields.length > 0;

  const handleConfirm = () => {
    // In a real app, this would save the task to the database
    console.log("Task confirmed and logged:", taskData);
    navigate("/dashboard");
  };

  const handleEdit = () => {
    navigate("/edit-task");
  };

  const handleBack = () => {
    navigate("/ai-processing");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto">
      {/* 1️⃣ Header */}
      <header className="bg-royal-blue px-4 py-3 flex items-center justify-between">
        {/* Left: Back arrow */}
        <button
          onClick={handleBack}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>

        {/* Center: Title */}
        <h1 className="text-white text-lg font-bold">Confirm Task</h1>

        {/* Right: Info icon */}
        <button className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors">
          <Info className="w-5 h-5 text-gold" />
        </button>
      </header>

      {/* Content */}
      <div className="flex-1 px-4 py-6 space-y-4">
        {/* 2️⃣ AI Interpretation Card */}
        <div className="bg-white border border-platinum rounded-2xl p-6 shadow-lg">
          <div className="space-y-4">
            {/* Task Name */}
            <div className="pb-3 border-b border-platinum">
              <div className="flex items-center mb-2">
                <Tag className="w-4 h-4 text-midnight-green mr-2" />
                <span className="text-midnight-green text-sm font-medium">
                  Task Name
                </span>
              </div>
              <p className="text-midnight-green text-base font-semibold">
                {taskData.taskName}
              </p>
            </div>

            {/* Time */}
            <div className="pb-3 border-b border-platinum">
              <div className="flex items-center mb-2">
                <Clock className="w-4 h-4 text-midnight-green mr-2" />
                <span className="text-midnight-green text-sm font-medium">
                  Time
                </span>
              </div>
              <p className="text-platinum text-sm">{taskData.time}</p>
            </div>

            {/* Category */}
            <div className="pb-3 border-b border-platinum">
              <div className="flex items-center mb-2">
                <Tag className="w-4 h-4 text-midnight-green mr-2" />
                <span className="text-midnight-green text-sm font-medium">
                  Category
                </span>
              </div>
              <p className="text-midnight-green text-sm">{taskData.category}</p>
            </div>

            {/* Location */}
            <div className="pb-3 border-b border-platinum">
              <div className="flex items-center mb-2">
                <MapPin className="w-4 h-4 text-midnight-green mr-2" />
                <span className="text-midnight-green text-sm font-medium">
                  Location
                </span>
              </div>
              <p className="text-midnight-green text-sm">{taskData.location}</p>
            </div>

            {/* Missing Fields */}
            {taskData.missingFields.length > 0 && (
              <div className="pt-2">
                <div className="flex items-center mb-3">
                  <AlertTriangle
                    className={`w-4 h-4 mr-2 ${hasCriticalMissing ? "text-red-500" : "text-gold"}`}
                  />
                  <span
                    className={`text-sm font-bold ${hasCriticalMissing ? "text-red-500" : "text-gold"}`}
                  >
                    Missing Fields
                  </span>
                </div>
                <div className="space-y-2">
                  {taskData.missingFields.map((field, index) => (
                    <div key={index} className="flex items-center">
                      <div
                        className={`w-2 h-2 rounded-full mr-2 ${
                          field === "Patient ID" ? "bg-red-500" : "bg-gold"
                        }`}
                      ></div>
                      <span
                        className={`text-sm font-medium ${
                          field === "Patient ID" ? "text-red-500" : "text-gold"
                        }`}
                      >
                        ⚠ {field} Missing
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* 3️⃣ Warning Banner */}
        {hasWarnings && (
          <div
            className={`rounded-lg p-4 flex items-center ${
              hasCriticalMissing ? "bg-red-500" : "bg-gold"
            }`}
          >
            <AlertTriangle className="w-5 h-5 text-white mr-3 flex-shrink-0" />
            <div className="text-white text-sm font-medium">
              {hasCriticalMissing
                ? "Critical information missing. Patient ID is required for healthcare tasks."
                : "Some fields are missing. Please review before logging."}
            </div>
          </div>
        )}
      </div>

      {/* 4️⃣ Buttons */}
      <div className="px-4 pb-6 space-y-3">
        {/* Primary Button - Confirm & Log */}
        <button
          onClick={handleConfirm}
          className="w-full bg-gold text-royal-blue font-bold py-4 px-6 rounded-xl hover:bg-yellow-400 transition-all duration-200 transform hover:scale-105 shadow-lg"
        >
          Confirm & Log Task
        </button>

        {/* Secondary Button - Edit */}
        <button
          onClick={handleEdit}
          className="w-full bg-white border border-platinum text-midnight-green font-medium py-4 px-6 rounded-xl hover:bg-gray-50 transition-colors duration-200 shadow-sm"
        >
          Edit Details
        </button>
      </div>

      {/* 5️⃣ Footer */}
      <div className="bg-platinum px-4 py-3">
        <p className="text-midnight-green text-xs text-center">
          This entry will be saved to your audit logs
        </p>
      </div>
    </div>
  );
}
