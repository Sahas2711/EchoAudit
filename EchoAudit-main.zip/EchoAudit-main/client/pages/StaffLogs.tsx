import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Download,
  Calendar,
  Search,
  ChevronDown,
  Filter,
  Home,
  Bell,
  FileText,
  User,
  X,
} from "lucide-react";

interface StaffLog {
  id: string;
  staffName: string;
  taskTitle: string;
  timestamp: string;
  date: string;
  status: "complete" | "missing";
  fieldsCompleted: number;
  totalFields: number;
  missingFields?: string[];
}

export default function StaffLogs() {
  const navigate = useNavigate();

  const [showFilters, setShowFilters] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);

  const [filters, setFilters] = useState({
    date: "",
    staffName: "",
    status: "all",
  });

  const [staffLogs] = useState<StaffLog[]>([
    {
      id: "1",
      staffName: "Dr. Sarah Johnson",
      taskTitle: "Patient rounds - Ward A",
      timestamp: "14:30",
      date: "2025-01-15",
      status: "complete",
      fieldsCompleted: 5,
      totalFields: 5,
    },
    {
      id: "2",
      staffName: "Nurse Mike Chen",
      taskTitle: "Equipment check - ICU",
      timestamp: "13:45",
      date: "2025-01-15",
      status: "missing",
      fieldsCompleted: 3,
      totalFields: 5,
      missingFields: ["Patient ID", "Supervisor Approval"],
    },
    {
      id: "3",
      staffName: "Tech Jessica Williams",
      taskTitle: "Safety inspection - Floor 2",
      timestamp: "12:20",
      date: "2025-01-15",
      status: "complete",
      fieldsCompleted: 4,
      totalFields: 4,
    },
    {
      id: "4",
      staffName: "Dr. Robert Taylor",
      taskTitle: "Surgery prep - OR 3",
      timestamp: "11:15",
      date: "2025-01-15",
      status: "missing",
      fieldsCompleted: 4,
      totalFields: 6,
      missingFields: [
        "Pre-op checklist",
        "Anesthesia notes",
        "Patient consent",
      ],
    },
    {
      id: "5",
      staffName: "Nurse Emily Davis",
      taskTitle: "Medication administration",
      timestamp: "10:30",
      date: "2025-01-15",
      status: "complete",
      fieldsCompleted: 5,
      totalFields: 5,
    },
  ]);

  const handleBack = () => {
    navigate("/manager-dashboard");
  };

  const handleExportPDF = () => {
    console.log("Exporting to PDF...");
    setShowExportModal(false);
  };

  const handleExportExcel = () => {
    console.log("Exporting to Excel...");
    setShowExportModal(false);
  };

  const handleFilterChange = (field: string, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const applyFilters = () => {
    console.log("Applying filters:", filters);
    setShowFilters(false);
  };

  // Filter logs based on current filter settings
  const filteredLogs = staffLogs.filter((log) => {
    const matchesDate = !filters.date || log.date === filters.date;
    const matchesStaff =
      !filters.staffName ||
      log.staffName.toLowerCase().includes(filters.staffName.toLowerCase());
    const matchesStatus =
      filters.status === "all" ||
      (filters.status === "complete" && log.status === "complete") ||
      (filters.status === "missing" && log.status === "missing");

    return matchesDate && matchesStaff && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto">
      {/* 1️⃣ Header */}
      <header className="bg-royal-blue px-4 py-3 flex items-center justify-between">
        {/* Left: Back Arrow */}
        <button
          onClick={handleBack}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>

        {/* Center: Title */}
        <h1 className="text-white text-lg font-bold">Staff Logs</h1>

        {/* Right: Export Icon */}
        <button
          onClick={() => setShowExportModal(true)}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <Download className="w-5 h-5 text-gold" />
        </button>
      </header>

      {/* 2️⃣ Filter Bar (collapsible) */}
      <div className="bg-platinum px-4 py-3">
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="w-full flex items-center justify-between text-royal-blue font-medium"
        >
          <span>Filters</span>
          <ChevronDown
            className={`w-4 h-4 transition-transform ${showFilters ? "rotate-180" : ""}`}
          />
        </button>

        {showFilters && (
          <div className="mt-3 space-y-3">
            {/* Date Picker */}
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-royal-blue" />
              <input
                type="date"
                value={filters.date}
                onChange={(e) => handleFilterChange("date", e.target.value)}
                className="w-full pl-10 pr-3 py-2 bg-white border border-platinum rounded-lg text-royal-blue focus:outline-none focus:ring-2 focus:ring-gold"
              />
            </div>

            {/* Staff Name Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-royal-blue" />
              <input
                type="text"
                placeholder="Search staff..."
                value={filters.staffName}
                onChange={(e) =>
                  handleFilterChange("staffName", e.target.value)
                }
                className="w-full pl-10 pr-3 py-2 bg-white border border-platinum rounded-lg text-royal-blue placeholder-platinum focus:outline-none focus:ring-2 focus:ring-gold"
              />
            </div>

            {/* Status Dropdown */}
            <div className="relative">
              <select
                value={filters.status}
                onChange={(e) => handleFilterChange("status", e.target.value)}
                className="w-full px-3 py-2 bg-white border border-platinum rounded-lg text-royal-blue appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-gold"
              >
                <option value="all">All Status</option>
                <option value="complete">Complete</option>
                <option value="missing">Missing Info</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-royal-blue pointer-events-none" />
            </div>

            {/* Filter Button */}
            <button
              onClick={applyFilters}
              className="w-full bg-gold text-royal-blue font-bold py-2 px-4 rounded-lg hover:bg-yellow-400 transition-colors flex items-center justify-center"
            >
              <Filter className="w-4 h-4 mr-2" />
              Apply Filters
            </button>
          </div>
        )}
      </div>

      {/* 3️⃣ Table of Staff Logs (Scrollable) */}
      <div className="flex-1 px-4 py-4 space-y-3 overflow-y-auto">
        {filteredLogs.length > 0 ? (
          filteredLogs.map((log) => (
            <div
              key={log.id}
              className={`bg-white border border-platinum rounded-lg p-4 shadow-sm ${
                log.status === "missing" ? "border-l-4 border-l-gold" : ""
              }`}
            >
              {/* Top row: Staff Name + Status badge */}
              <div className="flex items-center justify-between mb-2">
                <span className="text-royal-blue font-bold text-sm">
                  {log.staffName}
                </span>
                {log.status === "complete" ? (
                  <span className="bg-gold text-royal-blue text-xs font-medium px-2 py-1 rounded-full">
                    ✅ Complete
                  </span>
                ) : (
                  <span className="text-red-500 text-xs font-medium px-2 py-1 rounded-full bg-red-50">
                    ⚠ Missing Info
                  </span>
                )}
              </div>

              {/* Middle row: Task Title + Timestamp */}
              <div className="flex items-center justify-between mb-2">
                <span className="text-royal-blue text-sm font-medium">
                  {log.taskTitle}
                </span>
                <span className="text-platinum text-xs">{log.timestamp}</span>
              </div>

              {/* Bottom row: Fields completed count */}
              <div className="flex items-center justify-between mb-2">
                <span className="text-midnight-green text-xs">
                  {log.fieldsCompleted}/{log.totalFields} fields completed
                </span>
                <div className="flex items-center">
                  <div className="w-16 bg-platinum rounded-full h-2 mr-2">
                    <div
                      className="bg-gold h-2 rounded-full"
                      style={{
                        width: `${(log.fieldsCompleted / log.totalFields) * 100}%`,
                      }}
                    ></div>
                  </div>
                  <span className="text-xs text-platinum">
                    {Math.round((log.fieldsCompleted / log.totalFields) * 100)}%
                  </span>
                </div>
              </div>

              {/* 4️⃣ Missing Fields (if any) */}
              {log.missingFields && log.missingFields.length > 0 && (
                <div className="mt-3 pt-3 border-t border-platinum">
                  <div className="text-royal-blue text-xs font-medium mb-1">
                    Missing Fields:
                  </div>
                  <div className="space-y-1">
                    {log.missingFields.map((field, index) => (
                      <div key={index} className="text-royal-blue text-xs">
                        • {field}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center py-12">
            <FileText className="w-16 h-16 text-platinum mb-4" />
            <h3 className="text-midnight-green text-lg font-medium mb-2">
              No logs found
            </h3>
            <p className="text-platinum text-sm text-center">
              Adjust your filters or try a different search
            </p>
          </div>
        )}
      </div>

      {/* Summary */}
      {filteredLogs.length > 0 && (
        <div className="px-4 py-3 bg-white border-t border-platinum">
          <div className="flex justify-between items-center text-xs">
            <span className="text-midnight-green">
              Showing {filteredLogs.length} logs
            </span>
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <div className="w-2 h-2 bg-gold rounded-full mr-1"></div>
                <span className="text-platinum">
                  {filteredLogs.filter((l) => l.status === "complete").length}{" "}
                  Complete
                </span>
              </div>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-red-500 rounded-full mr-1"></div>
                <span className="text-platinum">
                  {filteredLogs.filter((l) => l.status === "missing").length}{" "}
                  Missing
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6️⃣ Footer Navigation */}
      <nav className="bg-royal-blue px-4 py-3">
        <div className="grid grid-cols-4 gap-1">
          <button
            onClick={() => navigate("/manager-dashboard")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <Home className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Dashboard</span>
          </button>

          <button
            onClick={() => navigate("/alerts")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <Bell className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Alerts</span>
          </button>

          {/* Logs - Active */}
          <button className="flex flex-col items-center py-2">
            <FileText className="w-5 h-5 text-gold mb-1" />
            <span className="text-gold text-xs font-medium">Logs</span>
          </button>

          <button
            onClick={() => navigate("/settings")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <User className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Profile</span>
          </button>
        </div>
      </nav>

      {/* 5️⃣ Export Options Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-royal-blue font-bold text-lg">
                Export Options
              </h3>
              <button
                onClick={() => setShowExportModal(false)}
                className="text-platinum hover:text-midnight-green"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <button
                onClick={handleExportPDF}
                className="w-full bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors flex items-center justify-center"
              >
                <Download className="w-4 h-4 mr-2" />
                Export as PDF
              </button>

              <button
                onClick={handleExportExcel}
                className="w-full bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors flex items-center justify-center"
              >
                <Download className="w-4 h-4 mr-2" />
                Export as Excel
              </button>

              <button
                onClick={() => setShowExportModal(false)}
                className="w-full bg-white border border-platinum text-royal-blue font-medium py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
