import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, EyeOff, Mail, Lock, ArrowLeft } from "lucide-react";

export default function Index() {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleBack = () => {
    navigate("/");
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle login logic here
    console.log("Staff login attempt with:", { email, password });
    // Navigate to staff dashboard after successful login
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-royal-blue flex flex-col">
      {/* Back Button */}
      <div className="absolute top-4 left-4 z-10">
        <button
          onClick={handleBack}
          className="w-10 h-10 flex items-center justify-center bg-white bg-opacity-10 hover:bg-opacity-20 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
      </div>

      {/* Top Section - Branding */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-8">
        {/* App Logo and Name */}
        <div className="text-center mb-12">
          <div className="w-24 h-24 mx-auto mb-6 bg-gold rounded-full flex items-center justify-center">
            <div className="text-4xl font-bold text-royal-blue">EA</div>
          </div>
          <h1 className="text-white text-3xl font-bold tracking-wide">
            EchoAudit
          </h1>
        </div>

        {/* Welcome Text */}
        <div className="text-center mb-8">
          <h2 className="text-gold text-2xl font-semibold mb-2">
            Staff Access
          </h2>
          <p className="text-platinum text-base">
            Login to continue your audit tasks
          </p>
        </div>

        {/* Login Form */}
        <div className="w-full max-w-sm">
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            <form onSubmit={handleLogin} className="space-y-4">
              {/* Email Field */}
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-midnight-green" />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Staff email"
                  className="w-full pl-10 pr-3 py-3 border border-platinum rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
                  required
                />
              </div>

              {/* Password Field */}
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-midnight-green" />
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Staff password"
                  className="w-full pl-10 pr-12 py-3 border border-platinum rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
                  required
                />
                <button
                  type="button"
                  onClick={togglePasswordVisibility}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5 text-midnight-green" />
                  ) : (
                    <Eye className="h-5 w-5 text-midnight-green" />
                  )}
                </button>
              </div>

              {/* Login Button */}
              <button
                type="submit"
                className="w-full bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors duration-200"
              >
                Access Staff Dashboard
              </button>
            </form>

            {/* Continue with Google Button */}
            <button
              type="button"
              className="w-full mt-4 bg-white text-midnight-green font-medium py-3 px-4 border border-platinum rounded-lg hover:bg-gray-50 transition-colors duration-200"
            >
              Continue with Google
            </button>
          </div>

          {/* Utility Links */}
          <div className="text-center mt-6 space-y-3">
            <button className="text-gold text-sm hover:underline">
              Forgot Password?
            </button>
            <p className="text-white text-sm">
              Don't have an account?{" "}
              <button className="text-gold hover:underline font-medium">
                Sign up
              </button>
            </p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="text-center pb-6">
        <p className="text-platinum text-xs">© 2025 EchoAudit</p>
      </div>
    </div>
  );
}
