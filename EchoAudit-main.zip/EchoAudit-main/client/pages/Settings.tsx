import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Settings as SettingsIcon,
  User,
  Bell,
  Building,
  Mic,
  MicOff,
  Plug,
  ChevronDown,
  ChevronRight,
  Home,
  AlertTriangle,
  FileText,
  Edit,
} from "lucide-react";

export default function Settings() {
  const navigate = useNavigate();

  // Profile data
  const [profileData, setProfileData] = useState({
    name: "John Manager",
    email: "john.manager@echoaudit.com",
    role: "Manager",
    avatar: "",
  });

  // Notification preferences
  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    smsAlerts: false,
  });

  // Industry template
  const [industryTemplate, setIndustryTemplate] = useState("healthcare");

  // Integration settings
  const [showIntegrations, setShowIntegrations] = useState(false);
  const [integrations, setIntegrations] = useState({
    emr: false,
    sap: false,
    apis: false,
  });

  // Voice command states
  const [isListening, setIsListening] = useState(false);
  const [voiceText, setVoiceText] = useState("");
  const [showVoiceConfirmation, setShowVoiceConfirmation] = useState(false);
  const [voiceCommand, setVoiceCommand] = useState("");

  const industryOptions = [
    { value: "healthcare", label: "🏥 Healthcare", icon: "🏥" },
    { value: "manufacturing", label: "🏭 Manufacturing", icon: "🏭" },
    { value: "corporate", label: "🏢 Corporate", icon: "🏢" },
    { value: "custom", label: "📊 Custom", icon: "📊" },
  ];

  const handleBack = () => {
    navigate("/manager-dashboard");
  };

  const handleEditProfile = () => {
    console.log("Edit profile functionality");
    // In a real app, this would open an edit profile modal
  };

  const handleNotificationToggle = (setting: keyof typeof notifications) => {
    setNotifications((prev) => ({
      ...prev,
      [setting]: !prev[setting],
    }));
  };

  const handleSaveTemplate = () => {
    console.log("Saving industry template:", industryTemplate);
    // In a real app, this would save to backend
  };

  const handleIntegrationConnect = (integration: string) => {
    console.log(`Connecting ${integration} integration`);
    setIntegrations((prev) => ({
      ...prev,
      [integration]: !prev[integration as keyof typeof prev],
    }));
  };

  // Voice command handlers
  const handleVoiceCommand = () => {
    setIsListening(!isListening);
    if (!isListening) {
      setVoiceText("Listening...");
      // Simulate voice recognition
      setTimeout(() => {
        const sampleCommands = [
          "Turn on email alerts",
          "Switch template to Healthcare",
          "Connect SAP integration",
          "Turn off SMS alerts",
        ];
        const randomCommand =
          sampleCommands[Math.floor(Math.random() * sampleCommands.length)];
        setVoiceText(randomCommand);
        setVoiceCommand(randomCommand);
        processVoiceCommand(randomCommand);
      }, 2000);
    } else {
      setVoiceText("");
      setVoiceCommand("");
    }
  };

  const processVoiceCommand = (command: string) => {
    const lowerCommand = command.toLowerCase();
    setShowVoiceConfirmation(true);
    setIsListening(false);
  };

  const confirmVoiceCommand = () => {
    const lowerCommand = voiceCommand.toLowerCase();

    if (lowerCommand.includes("email alerts")) {
      if (lowerCommand.includes("turn on") || lowerCommand.includes("enable")) {
        setNotifications((prev) => ({ ...prev, emailAlerts: true }));
      } else if (
        lowerCommand.includes("turn off") ||
        lowerCommand.includes("disable")
      ) {
        setNotifications((prev) => ({ ...prev, emailAlerts: false }));
      }
    } else if (lowerCommand.includes("sms alerts")) {
      if (lowerCommand.includes("turn on") || lowerCommand.includes("enable")) {
        setNotifications((prev) => ({ ...prev, smsAlerts: true }));
      } else if (
        lowerCommand.includes("turn off") ||
        lowerCommand.includes("disable")
      ) {
        setNotifications((prev) => ({ ...prev, smsAlerts: false }));
      }
    } else if (lowerCommand.includes("template")) {
      if (lowerCommand.includes("healthcare")) {
        setIndustryTemplate("healthcare");
      } else if (lowerCommand.includes("manufacturing")) {
        setIndustryTemplate("manufacturing");
      } else if (lowerCommand.includes("corporate")) {
        setIndustryTemplate("corporate");
      } else if (lowerCommand.includes("custom")) {
        setIndustryTemplate("custom");
      }
    } else if (lowerCommand.includes("connect")) {
      if (lowerCommand.includes("sap")) {
        handleIntegrationConnect("sap");
      } else if (lowerCommand.includes("emr")) {
        handleIntegrationConnect("emr");
      }
    }

    setShowVoiceConfirmation(false);
    setVoiceCommand("");
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto">
      {/* 1️⃣ Header */}
      <header className="bg-royal-blue px-4 py-3 flex items-center justify-between">
        {/* Left: Back Arrow */}
        <button
          onClick={handleBack}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>

        {/* Center: Title */}
        <h1 className="text-white text-lg font-bold">Settings</h1>

        {/* Right: Gear Icon */}
        <div className="w-8 h-8 flex items-center justify-center">
          <SettingsIcon className="w-5 h-5 text-gold" />
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 px-4 py-6 space-y-6">
        {/* 2��⃣ Profile Section */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center mb-4">
            {/* Avatar */}
            <div className="w-16 h-16 rounded-full bg-royal-blue text-white flex items-center justify-center font-bold text-lg mr-4">
              {getInitials(profileData.name)}
            </div>

            <div className="flex-1">
              {/* Name */}
              <h2 className="text-royal-blue font-bold text-lg">
                {profileData.name}
              </h2>

              {/* Email */}
              <p className="text-platinum text-sm mb-2">{profileData.email}</p>

              {/* Role Badge */}
              <span className="bg-gold text-royal-blue px-3 py-1 rounded-full text-xs font-bold">
                {profileData.role}
              </span>
            </div>
          </div>

          {/* Edit Profile Button */}
          <button
            onClick={handleEditProfile}
            className="w-full bg-white border border-platinum text-royal-blue font-medium py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center"
          >
            <Edit className="w-4 h-4 mr-2" />
            Edit Profile
          </button>
        </div>

        {/* 3️⃣ Notification Preferences */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-royal-blue font-bold text-base">
              Notifications
            </h3>

            {/* Voice Support Button */}
            <button
              onClick={handleVoiceCommand}
              className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
                isListening
                  ? "bg-gold animate-pulse"
                  : "bg-gold bg-opacity-20 hover:bg-opacity-40"
              }`}
            >
              {isListening ? (
                <MicOff className="w-4 h-4 text-royal-blue" />
              ) : (
                <Mic className="w-4 h-4 text-gold" />
              )}
            </button>
          </div>

          <div className="space-y-4">
            {/* Email Alerts */}
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-royal-blue bg-opacity-10 rounded-lg flex items-center justify-center mr-3">
                  <Bell className="w-4 h-4 text-royal-blue" />
                </div>
                <div>
                  <div className="text-midnight-green font-medium text-sm">
                    📧 Email Alerts
                  </div>
                  <div className="text-platinum text-xs">
                    Get critical staff alerts via email
                  </div>
                </div>
              </div>

              <button
                onClick={() => handleNotificationToggle("emailAlerts")}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notifications.emailAlerts ? "bg-gold" : "bg-platinum"
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                    notifications.emailAlerts
                      ? "translate-x-6"
                      : "translate-x-1"
                  }`}
                />
              </button>
            </div>

            {/* SMS Alerts */}
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-royal-blue bg-opacity-10 rounded-lg flex items-center justify-center mr-3">
                  <Bell className="w-4 h-4 text-royal-blue" />
                </div>
                <div>
                  <div className="text-midnight-green font-medium text-sm">
                    📱 SMS Alerts
                  </div>
                  <div className="text-platinum text-xs">
                    Get critical system alerts via SMS
                  </div>
                </div>
              </div>

              <button
                onClick={() => handleNotificationToggle("smsAlerts")}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  notifications.smsAlerts ? "bg-gold" : "bg-platinum"
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                    notifications.smsAlerts ? "translate-x-6" : "translate-x-1"
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* 4️⃣ Industry Template */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <h3 className="text-royal-blue font-bold text-base mb-4">
            Industry Template
          </h3>

          <div className="space-y-4">
            <div className="relative">
              <select
                value={industryTemplate}
                onChange={(e) => setIndustryTemplate(e.target.value)}
                className="w-full px-3 py-3 border border-platinum rounded-lg focus:outline-none focus:ring-2 focus:ring-gold text-midnight-green appearance-none cursor-pointer"
              >
                {industryOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-midnight-green pointer-events-none" />
            </div>

            <button
              onClick={handleSaveTemplate}
              className="w-full bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors"
            >
              Save Template
            </button>
          </div>
        </div>

        {/* 5️⃣ Integration Settings */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <button
            onClick={() => setShowIntegrations(!showIntegrations)}
            className="w-full px-6 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center">
              <Plug className="w-5 h-5 text-royal-blue mr-3" />
              <h3 className="text-royal-blue font-bold text-base">
                Integrations
              </h3>
            </div>
            <ChevronRight
              className={`w-4 h-4 text-royal-blue transition-transform ${showIntegrations ? "rotate-90" : ""}`}
            />
          </button>

          {showIntegrations && (
            <div className="px-6 pb-6 space-y-4 border-t border-platinum">
              <div className="pt-4">
                <p className="text-platinum text-xs mb-4">
                  Integrations are optional and for advanced use.
                </p>

                {/* EMR Integration */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-midnight-green font-medium text-sm">
                    EMR
                  </span>
                  <button
                    onClick={() => handleIntegrationConnect("emr")}
                    className={`px-4 py-2 rounded-lg text-xs font-medium transition-colors ${
                      integrations.emr
                        ? "bg-green-100 text-green-800"
                        : "bg-white border border-platinum text-royal-blue hover:bg-gray-50"
                    }`}
                  >
                    {integrations.emr ? "Connected" : "Link Account"}
                  </button>
                </div>

                {/* SAP Integration */}
                <div className="flex items-center justify-between mb-3">
                  <span className="text-midnight-green font-medium text-sm">
                    SAP
                  </span>
                  <button
                    onClick={() => handleIntegrationConnect("sap")}
                    className={`px-4 py-2 rounded-lg text-xs font-medium transition-colors ${
                      integrations.sap
                        ? "bg-green-100 text-green-800"
                        : "bg-gold text-royal-blue hover:bg-yellow-400"
                    }`}
                  >
                    {integrations.sap ? "Connected" : "Connect"}
                  </button>
                </div>

                {/* Other APIs */}
                <div className="flex items-center justify-between">
                  <span className="text-midnight-green font-medium text-sm">
                    Other APIs
                  </span>
                  <button
                    onClick={() => handleIntegrationConnect("apis")}
                    className="text-royal-blue text-xs hover:underline"
                  >
                    Manage
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 6️⃣ Footer Navigation */}
      <nav className="bg-royal-blue px-4 py-3">
        <div className="grid grid-cols-4 gap-1">
          <button
            onClick={() => navigate("/manager-dashboard")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <Home className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Dashboard</span>
          </button>

          <button
            onClick={() => navigate("/alerts")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <AlertTriangle className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Alerts</span>
          </button>

          <button
            onClick={() => navigate("/staff-logs")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <FileText className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Logs</span>
          </button>

          {/* Profile - Active */}
          <button className="flex flex-col items-center py-2">
            <User className="w-5 h-5 text-gold mb-1" />
            <span className="text-gold text-xs font-medium">Profile</span>
          </button>
        </div>
      </nav>

      {/* Voice Command Overlay */}
      {isListening && (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 m-4 max-w-sm w-full">
            <div className="text-center">
              <div className="w-16 h-16 bg-gold rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                <Mic className="w-8 h-8 text-royal-blue" />
              </div>
              <h3 className="text-royal-blue font-bold text-lg mb-2">
                Listening...
              </h3>
              <div className="text-midnight-green text-sm mb-4">
                {voiceText || "Speak your command"}
              </div>
              <div className="text-xs text-platinum">
                Try: "Turn on email alerts", "Switch template to Healthcare"
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Voice Command Confirmation */}
      {showVoiceConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <div className="text-center mb-4">
              <div className="w-12 h-12 bg-royal-blue rounded-full flex items-center justify-center mx-auto mb-3">
                <Mic className="w-6 h-6 text-gold" />
              </div>
              <h3 className="text-royal-blue font-bold text-lg mb-2">
                Voice Command
              </h3>
            </div>

            <div className="bg-royal-blue bg-opacity-10 rounded-lg p-3 mb-4">
              <div className="text-royal-blue text-sm font-medium">
                "{voiceCommand}"
              </div>
            </div>

            <div className="text-center text-xs text-platinum mb-4">
              Execute this command?
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => {
                  setShowVoiceConfirmation(false);
                  setVoiceCommand("");
                }}
                className="flex-1 bg-white border border-platinum text-midnight-green font-medium py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>

              <button
                onClick={confirmVoiceCommand}
                className="flex-1 bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
