import { useState } from "react";
import { WebAudioRecorder } from "../lib/audioUtils";
import { recordingManager } from "../lib/recordingManager";

export default function SimpleAudioTest() {
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [recorder, setRecorder] = useState<WebAudioRecorder | null>(null);

  const startRecording = async () => {
    try {
      setError(null);
      setAudioBlob(null);
      
      const newRecorder = new WebAudioRecorder();
      setRecorder(newRecorder);
      
      console.log("Starting recording...");
      await newRecorder.start();
      setIsRecording(true);
      
      console.log("Recording started successfully!");
    } catch (err) {
      console.error("Failed to start recording:", err);
      setError((err as Error).message);
    }
  };

  const stopRecording = async () => {
    if (!recorder) return;
    
    try {
      console.log("Stopping recording...");
      const blob = await recorder.stop();
      setIsRecording(false);
      setAudioBlob(blob);
      setRecorder(null);
      
      console.log("Recording stopped, blob size:", blob.size);
      
      // Automatically save the recording
      try {
        const savedRecording = await recordingManager.saveRecording(blob);
        console.log("Recording saved:", savedRecording.filename);
      } catch (saveError) {
        console.warn("Failed to save recording:", saveError);
      }
    } catch (err) {
      console.error("Failed to stop recording:", err);
      setError((err as Error).message);
      setIsRecording(false);
      setRecorder(null);
    }
  };

  const playAudio = () => {
    if (!audioBlob) return;
    
    const url = URL.createObjectURL(audioBlob);
    const audio = new Audio(url);
    audio.play().catch(err => {
      console.error("Failed to play audio:", err);
      setError("Failed to play audio");
    });
  };

  const downloadAudio = () => {
    if (!audioBlob) return;
    
    const url = URL.createObjectURL(audioBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `recording-${Date.now()}.webm`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-md mx-auto bg-white rounded-lg shadow-lg p-6">
        <h1 className="text-2xl font-bold mb-6 text-center">Simple Audio Test</h1>
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <strong>Error:</strong> {error}
          </div>
        )}
        
        <div className="space-y-4">
          {!isRecording ? (
            <button
              onClick={startRecording}
              className="w-full bg-blue-500 text-white py-3 px-4 rounded-lg hover:bg-blue-600 transition-colors"
            >
              Start Recording
            </button>
          ) : (
            <button
              onClick={stopRecording}
              className="w-full bg-red-500 text-white py-3 px-4 rounded-lg hover:bg-red-600 transition-colors"
            >
              Stop Recording
            </button>
          )}
          
          {audioBlob && (
            <div className="space-y-2">
              <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
                <strong>Success!</strong> Recording completed ({audioBlob.size} bytes)
              </div>
              
              <button
                onClick={playAudio}
                className="w-full bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 transition-colors"
              >
                Play Recording
              </button>
              
              <button
                onClick={downloadAudio}
                className="w-full bg-purple-500 text-white py-2 px-4 rounded hover:bg-purple-600 transition-colors"
              >
                Download Recording
              </button>
            </div>
          )}
        </div>
        
        <div className="mt-6 text-sm text-gray-600">
          <p><strong>Instructions:</strong></p>
          <ol className="list-decimal list-inside space-y-1 mt-2">
            <li>Click "Start Recording"</li>
            <li>Allow microphone permissions when prompted</li>
            <li>Speak into your microphone</li>
            <li>Click "Stop Recording"</li>
            <li>Test playback and download</li>
          </ol>
        </div>
      </div>
    </div>
  );
} 