import { useState, useEffect } from "react";
import { checkBrowserSupport, testMicrophoneAccess, getBrowserInfo } from "../lib/audioDebug";
import { WebAudioRecorder } from "../lib/audioUtils";

export default function AudioDebug() {
  const [browserSupport, setBrowserSupport] = useState<any>(null);
  const [micTest, setMicTest] = useState<any>(null);
  const [recordingTest, setRecordingTest] = useState<any>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [audioRecorder, setAudioRecorder] = useState<WebAudioRecorder | null>(null);
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (message: string) => {
    setLogs(prev => [...prev, `${new Date().toLocaleTimeString()}: ${message}`]);
  };

  useEffect(() => {
    addLog("Audio Debug Page Loaded");
    
    // Check browser support on load
    const support = checkBrowserSupport();
    setBrowserSupport(support);
    addLog(`Browser Support Check: ${JSON.stringify(support, null, 2)}`);
    
    // Initialize audio recorder
    const recorder = new WebAudioRecorder();
    setAudioRecorder(recorder);
    addLog("Audio Recorder initialized");
  }, []);

  const handleTestMicrophone = async () => {
    addLog("Testing microphone access...");
    try {
      const result = await testMicrophoneAccess();
      setMicTest(result);
      addLog(`Microphone Test Result: ${JSON.stringify(result, null, 2)}`);
    } catch (error) {
      addLog(`Microphone Test Error: ${error}`);
    }
  };

  const handleTestRecording = async () => {
    if (!audioRecorder) return;
    
    addLog("Testing audio recording...");
    setIsRecording(true);
    
    try {
      await audioRecorder.start();
      addLog("Recording started successfully");
      
      // Record for 3 seconds
      setTimeout(async () => {
        try {
          const blob = await audioRecorder.stop();
          setIsRecording(false);
          setRecordingTest({
            success: true,
            size: blob.size,
            type: blob.type,
            duration: "3 seconds"
          });
          addLog(`Recording completed: ${blob.size} bytes, type: ${blob.type}`);
        } catch (error) {
          setIsRecording(false);
          setRecordingTest({ success: false, error: error });
          addLog(`Recording failed: ${error}`);
        }
      }, 3000);
      
    } catch (error) {
      setIsRecording(false);
      setRecordingTest({ success: false, error: error });
      addLog(`Recording start failed: ${error}`);
    }
  };

  const handleCheckDevices = async () => {
    addLog("Checking available audio devices...");
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const audioInputs = devices.filter(device => device.kind === 'audioinput');
      addLog(`Found ${audioInputs.length} audio input devices:`);
      audioInputs.forEach((device, index) => {
        addLog(`  ${index + 1}. ${device.label || 'Unknown Device'} (${device.deviceId})`);
      });
    } catch (error) {
      addLog(`Device enumeration failed: ${error}`);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Audio Recording Debug</h1>
        
        {/* Browser Info */}
        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <h2 className="text-xl font-semibold mb-4">Browser Information</h2>
          <p className="text-gray-600 mb-2">Browser: {getBrowserInfo()}</p>
          <p className="text-gray-600 mb-2">URL: {window.location.href}</p>
          <p className="text-gray-600">Protocol: {window.location.protocol}</p>
        </div>

        {/* Browser Support */}
        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <h2 className="text-xl font-semibold mb-4">Browser Support</h2>
          {browserSupport && (
            <div className="space-y-2">
              <p>MediaDevices API: {browserSupport.hasMediaDevices ? '✅' : '❌'}</p>
              <p>getUserMedia: {browserSupport.hasGetUserMedia ? '✅' : '❌'}</p>
              <p>MediaRecorder: {browserSupport.hasMediaRecorder ? '✅' : '❌'}</p>
              <p>HTTPS/Localhost: {browserSupport.isHttps ? '✅' : '❌'}</p>
              <p>Supported Formats: {browserSupport.supportedMimeTypes.join(', ') || 'None'}</p>
              {browserSupport.errorMessage && (
                <p className="text-red-600">Error: {browserSupport.errorMessage}</p>
              )}
            </div>
          )}
        </div>

        {/* Test Buttons */}
        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <h2 className="text-xl font-semibold mb-4">Tests</h2>
          <div className="space-y-4">
            <button
              onClick={handleCheckDevices}
              className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            >
              Check Audio Devices
            </button>
            
            <button
              onClick={handleTestMicrophone}
              className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
            >
              Test Microphone Access
            </button>
            
            <button
              onClick={handleTestRecording}
              disabled={isRecording}
              className={`px-4 py-2 rounded ${
                isRecording 
                  ? 'bg-gray-400 cursor-not-allowed' 
                  : 'bg-purple-500 text-white hover:bg-purple-600'
              }`}
            >
              {isRecording ? 'Recording... (3s)' : 'Test Recording (3s)'}
            </button>
          </div>
        </div>

        {/* Test Results */}
        <div className="bg-white p-6 rounded-lg shadow mb-6">
          <h2 className="text-xl font-semibold mb-4">Test Results</h2>
          
          {micTest && (
            <div className="mb-4">
              <h3 className="font-semibold">Microphone Test:</h3>
              <pre className="bg-gray-100 p-2 rounded text-sm overflow-auto">
                {JSON.stringify(micTest, null, 2)}
              </pre>
            </div>
          )}
          
          {recordingTest && (
            <div className="mb-4">
              <h3 className="font-semibold">Recording Test:</h3>
              <pre className="bg-gray-100 p-2 rounded text-sm overflow-auto">
                {JSON.stringify(recordingTest, null, 2)}
              </pre>
            </div>
          )}
        </div>

        {/* Logs */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Debug Logs</h2>
          <div className="bg-black text-green-400 p-4 rounded font-mono text-sm h-64 overflow-y-auto">
            {logs.map((log, index) => (
              <div key={index}>{log}</div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
} 