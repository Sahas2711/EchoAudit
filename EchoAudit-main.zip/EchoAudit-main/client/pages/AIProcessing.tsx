import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Check, Brain, Clock, MapPin, AlertCircle } from "lucide-react";

export default function AIProcessing() {
  const navigate = useNavigate();
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState("Analyzing audio...");
  const [detectedDetails, setDetectedDetails] = useState({
    taskName: "",
    time: "",
    location: "",
    missingFields: ["Priority Level", "Assigned Team"],
  });
  const [showResults, setShowResults] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);

  // Simulate AI processing with realistic steps
  useEffect(() => {
    const steps = [
      { progress: 20, step: "Processing voice input...", delay: 1000 },
      { progress: 40, step: "Extracting task details...", delay: 1500 },
      { progress: 60, step: "Identifying keywords...", delay: 1200 },
      { progress: 80, step: "Validating information...", delay: 1000 },
      { progress: 100, step: "Analysis complete", delay: 800 },
    ];

    let timeouts: NodeJS.Timeout[] = [];
    let totalDelay = 0;

    steps.forEach((stepData, index) => {
      totalDelay += stepData.delay;

      const timeout = setTimeout(() => {
        setProgress(stepData.progress);
        setCurrentStep(stepData.step);

        if (stepData.progress >= 60) {
          setDetectedDetails({
            taskName: "Safety inspection - Equipment check",
            time: "2:45 PM",
            location: "Manufacturing Floor B",
            missingFields:
              stepData.progress === 100
                ? []
                : ["Priority Level", "Assigned Team"],
          });
          setShowResults(true);
        }

        if (stepData.progress === 100) {
          setCompletedSteps(["Task Name", "Time", "Location"]);
          setTimeout(() => navigate("/task-confirmation"), 2000);
        }
      }, totalDelay);

      timeouts.push(timeout);
    });

    return () => {
      timeouts.forEach((timeout) => clearTimeout(timeout));
    };
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-royal-blue to-midnight-green flex flex-col max-w-md mx-auto relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-10 left-4 w-1 h-1 bg-gold rounded-full animate-pulse opacity-60"></div>
      <div className="absolute top-1/4 right-8 w-2 h-2 bg-platinum rounded-full animate-pulse opacity-40"></div>
      <div className="absolute bottom-1/3 left-8 w-1.5 h-1.5 bg-gold rounded-full animate-pulse opacity-50"></div>

      {/* 2️⃣ Center Section - Loading Animation */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 py-16">
        {/* Circular spinner */}
        <div className="relative mb-8">
          {/* Outer spinning ring */}
          <div className="w-24 h-24 border-4 border-platinum border-t-gold rounded-full animate-spin"></div>

          {/* Inner pulsing dots */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="flex space-x-1">
              <div
                className="w-2 h-2 bg-gold rounded-full animate-bounce"
                style={{ animationDelay: "0s" }}
              ></div>
              <div
                className="w-2 h-2 bg-gold rounded-full animate-bounce"
                style={{ animationDelay: "0.2s" }}
              ></div>
              <div
                className="w-2 h-2 bg-gold rounded-full animate-bounce"
                style={{ animationDelay: "0.4s" }}
              ></div>
            </div>
          </div>
        </div>

        {/* Status text */}
        <div className="text-center mb-8">
          <h2 className="text-white text-lg font-bold mb-2">{currentStep}</h2>
          <p className="text-platinum text-sm">Using AI to extract details</p>
        </div>

        {/* 3️⃣ Progress Bar */}
        <div className="w-full max-w-sm mb-8">
          <div className="bg-platinum rounded-full h-3 overflow-hidden shadow-inner">
            <div
              className="bg-gold h-full rounded-full transition-all duration-1000 ease-out flex items-center justify-center"
              style={{ width: `${progress}%` }}
            >
              {progress > 20 && (
                <span className="text-white text-xs font-bold">
                  {progress}%
                </span>
              )}
            </div>
          </div>
        </div>

        {/* 4️⃣ Preview Box - AI Extraction */}
        {showResults && (
          <div className="w-full max-w-sm bg-white rounded-2xl p-6 shadow-2xl animate-fade-in">
            {/* Header with AI icon */}
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 bg-gold rounded-lg flex items-center justify-center mr-3">
                <Brain className="w-5 h-5 text-royal-blue" />
              </div>
              <h3 className="text-royal-blue font-bold text-base">
                Detected Details
              </h3>
            </div>

            {/* Detected information */}
            <div className="space-y-3">
              {/* Task Name */}
              <div className="flex items-center py-2 border-b border-platinum">
                <div className="flex items-center flex-1">
                  <div className="text-midnight-green text-sm font-medium mr-2">
                    Task Name:
                  </div>
                  <div className="text-midnight-green text-sm">
                    {detectedDetails.taskName}
                  </div>
                </div>
                {completedSteps.includes("Task Name") && (
                  <Check className="w-4 h-4 text-green-500 animate-bounce" />
                )}
              </div>

              {/* Time */}
              <div className="flex items-center py-2 border-b border-platinum">
                <Clock className="w-4 h-4 text-midnight-green mr-2" />
                <div className="flex items-center flex-1">
                  <div className="text-midnight-green text-sm font-medium mr-2">
                    Time:
                  </div>
                  <div className="text-midnight-green text-sm">
                    {detectedDetails.time}
                  </div>
                </div>
                {completedSteps.includes("Time") && (
                  <Check className="w-4 h-4 text-green-500 animate-bounce" />
                )}
              </div>

              {/* Location */}
              <div className="flex items-center py-2 border-b border-platinum">
                <MapPin className="w-4 h-4 text-midnight-green mr-2" />
                <div className="flex items-center flex-1">
                  <div className="text-midnight-green text-sm font-medium mr-2">
                    Location:
                  </div>
                  <div className="text-midnight-green text-sm">
                    {detectedDetails.location}
                  </div>
                </div>
                {completedSteps.includes("Location") && (
                  <Check className="w-4 h-4 text-green-500 animate-bounce" />
                )}
              </div>

              {/* Missing Fields */}
              {detectedDetails.missingFields.length > 0 && (
                <div className="flex items-start py-2">
                  <AlertCircle className="w-4 h-4 text-gold mr-2 mt-0.5" />
                  <div className="flex-1">
                    <div className="text-gold text-sm font-bold mb-1">
                      Missing Fields:
                    </div>
                    {detectedDetails.missingFields.map((field, index) => (
                      <div key={index} className="text-gold text-sm">
                        • {field}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Completion animation */}
        {progress === 100 && (
          <div className="mt-6 text-center animate-fade-in">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-3 animate-bounce">
              <Check className="w-8 h-8 text-white" />
            </div>
            <p className="text-white text-sm">Redirecting to confirmation...</p>
          </div>
        )}
      </div>

      {/* Custom animations */}
      <style>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade-in {
          animation: fade-in 0.5s ease-out;
        }
      `}</style>
    </div>
  );
}
