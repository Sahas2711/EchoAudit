import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-royal-blue flex flex-col items-center justify-center px-6">
      <div className="text-center">
        {/* App Logo */}
        <div className="w-16 h-16 mx-auto mb-6 bg-gold rounded-full flex items-center justify-center">
          <div className="text-2xl font-bold text-royal-blue">EA</div>
        </div>

        <h1 className="text-6xl font-bold text-gold mb-4">404</h1>
        <p className="text-xl text-white mb-2">Oops! Page not found</p>
        <p className="text-platinum mb-8">
          The page you're looking for doesn't exist.
        </p>

        <Link
          to="/"
          className="inline-block bg-gold text-royal-blue font-bold py-3 px-6 rounded-lg hover:bg-yellow-400 transition-colors duration-200"
        >
          Return to Login
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
