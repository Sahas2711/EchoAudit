import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Filter, AlertTriangle, Info, Bell } from "lucide-react";

interface Alert {
  id: string;
  title: string;
  timestamp: string;
  severity: "high" | "medium" | "low";
  resolved: boolean;
}

export default function Alerts() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<"active" | "resolved">("active");

  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: "1",
      title: "Patient oxygen supply low",
      timestamp: "Aug 13, 14:35",
      severity: "high",
      resolved: false,
    },
    {
      id: "2",
      title: "Temperature monitoring required",
      timestamp: "Aug 13, 13:20",
      severity: "medium",
      resolved: false,
    },
    {
      id: "3",
      title: "Equipment maintenance scheduled",
      timestamp: "Aug 13, 12:45",
      severity: "low",
      resolved: false,
    },
    {
      id: "4",
      title: "Daily inspection completed",
      timestamp: "Aug 13, 10:30",
      severity: "low",
      resolved: true,
    },
    {
      id: "5",
      title: "Emergency protocol activated",
      timestamp: "Aug 12, 16:20",
      severity: "high",
      resolved: true,
    },
  ]);

  const handleBack = () => {
    navigate("/dashboard");
  };

  const handleResolve = (alertId: string) => {
    setAlerts((prev) =>
      prev.map((alert) =>
        alert.id === alertId ? { ...alert, resolved: true } : alert,
      ),
    );
  };

  const handleEscalate = (alertId: string) => {
    console.log("Escalating alert:", alertId);
    // In a real app, this would trigger escalation workflow
  };

  const filteredAlerts = alerts.filter((alert) =>
    activeTab === "active" ? !alert.resolved : alert.resolved,
  );

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "high":
        return (
          <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center">
            <AlertTriangle className="w-4 h-4 text-white" />
          </div>
        );
      case "medium":
        return (
          <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center">
            <AlertTriangle className="w-4 h-4 text-royal-blue" />
          </div>
        );
      case "low":
        return (
          <div className="w-8 h-8 bg-platinum rounded-full flex items-center justify-center">
            <Info className="w-4 h-4 text-midnight-green" />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto">
      {/* 1️⃣ Header */}
      <header className="bg-royal-blue px-4 py-3 flex items-center justify-between">
        {/* Left: Back arrow */}
        <button
          onClick={handleBack}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>

        {/* Center: Title */}
        <h1 className="text-white text-lg font-bold">Alerts</h1>

        {/* Right: Filter icon */}
        <button className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors">
          <Filter className="w-5 h-5 text-gold" />
        </button>
      </header>

      {/* 2️⃣ Tab Switcher */}
      <div className="bg-platinum px-4 py-3">
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setActiveTab("active")}
            className={`py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
              activeTab === "active"
                ? "bg-gold text-royal-blue font-bold shadow-sm"
                : "bg-white text-midnight-green"
            }`}
          >
            Active ({alerts.filter((a) => !a.resolved).length})
          </button>
          <button
            onClick={() => setActiveTab("resolved")}
            className={`py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
              activeTab === "resolved"
                ? "bg-gold text-royal-blue font-bold shadow-sm"
                : "bg-white text-midnight-green"
            }`}
          >
            Resolved ({alerts.filter((a) => a.resolved).length})
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-4 py-4">
        {/* 3️⃣ Alert Cards */}
        {filteredAlerts.length > 0 ? (
          <div className="space-y-3">
            {filteredAlerts.map((alert) => (
              <div
                key={alert.id}
                className="bg-white border border-platinum rounded-lg p-4 shadow-sm"
              >
                <div className="flex items-start space-x-3">
                  {/* Left Side: Severity icon */}
                  {getSeverityIcon(alert.severity)}

                  {/* Right Side: Content */}
                  <div className="flex-1">
                    <h3 className="text-midnight-green font-bold text-sm mb-1">
                      {alert.title}
                    </h3>
                    <p className="text-platinum text-xs mb-3">
                      {alert.timestamp}
                    </p>

                    {/* 4️⃣ Action Buttons */}
                    {!alert.resolved && (
                      <div className="flex space-x-2">
                        <button
                          onClick={() => handleResolve(alert.id)}
                          className="bg-gold text-royal-blue text-xs font-medium py-2 px-4 rounded-lg hover:bg-yellow-400 transition-colors"
                        >
                          Resolve
                        </button>
                        <button
                          onClick={() => handleEscalate(alert.id)}
                          className="bg-white border border-platinum text-midnight-green text-xs font-medium py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          Escalate
                        </button>
                      </div>
                    )}

                    {alert.resolved && (
                      <div className="flex items-center">
                        <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center mr-2">
                          <div className="w-2 h-2 bg-white rounded-full"></div>
                        </div>
                        <span className="text-green-600 text-xs font-medium">
                          Resolved
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* 5️⃣ Empty State */
          <div className="flex-1 flex flex-col items-center justify-center py-12">
            <div className="w-16 h-16 bg-platinum rounded-full flex items-center justify-center mb-4">
              <Bell className="w-8 h-8 text-midnight-green" />
            </div>
            <h3 className="text-midnight-green text-lg font-medium mb-2">
              {activeTab === "active"
                ? "No active alerts"
                : "No resolved alerts"}
            </h3>
            <p className="text-platinum text-sm text-center">
              {activeTab === "active"
                ? "You're all caught up!"
                : "Resolved alerts will appear here"}
            </p>
          </div>
        )}
      </div>

      {/* Summary footer */}
      <div className="bg-white border-t border-platinum px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
              <span className="text-midnight-green text-xs">
                {
                  alerts.filter((a) => a.severity === "high" && !a.resolved)
                    .length
                }{" "}
                High
              </span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-gold rounded-full mr-2"></div>
              <span className="text-midnight-green text-xs">
                {
                  alerts.filter((a) => a.severity === "medium" && !a.resolved)
                    .length
                }{" "}
                Medium
              </span>
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-platinum rounded-full mr-2"></div>
              <span className="text-midnight-green text-xs">
                {
                  alerts.filter((a) => a.severity === "low" && !a.resolved)
                    .length
                }{" "}
                Low
              </span>
            </div>
          </div>
          <span className="text-platinum text-xs">
            Total: {filteredAlerts.length}
          </span>
        </div>
      </div>
    </div>
  );
}
