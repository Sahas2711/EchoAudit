import { useNavigate } from "react-router-dom";
import { BarChart3, Mic, HelpCircle, LogIn } from "lucide-react";

export default function RoleSelection() {
  const navigate = useNavigate();

  const handleManagerRole = () => {
    // In a real app, this would set the user role in context/storage
    console.log("Selected role: Manager");
    navigate("/manager-login");
  };

  const handleStaffRole = () => {
    // In a real app, this would set the user role in context/storage
    console.log("Selected role: Staff");
    // Staff users need to go through login first
    navigate("/login");
  };

  // Since Role Selection is now the root page, we don't need a login handler

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto">
      {/* Header (Top Bar) */}
      <header className="bg-royal-blue px-4 py-3 flex items-center justify-between">
        {/* Left: EchoAudit Logo */}
        <div className="flex items-center">
          <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center mr-2">
            <div className="text-sm font-bold text-royal-blue">EA</div>
          </div>
          <span className="text-white text-lg font-bold">EchoAudit</span>
        </div>

        {/* Right: Help link */}
        <div className="flex items-center">
          <button className="text-white hover:text-gold transition-colors text-sm font-medium flex items-center">
            <HelpCircle className="w-4 h-4 mr-1" />
            Help
          </button>
        </div>
      </header>

      {/* Main Section (Centered) */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-8">
        {/* Title and Subtitle */}
        <div className="text-center mb-8">
          <h1 className="text-royal-blue text-2xl font-bold mb-3">
            Select Your Role
          </h1>
          <p className="text-midnight-green text-base">
            Choose how you want to use EchoAudit
          </p>
        </div>

        {/* Cards (Two Options) */}
        <div className="w-full space-y-4">
          {/* Manager Card */}
          <div className="bg-white border border-platinum rounded-2xl p-6 shadow-sm hover:shadow-md transition-all duration-200">
            <div className="flex items-center mb-4">
              {/* Icon */}
              <div className="w-12 h-12 bg-royal-blue bg-opacity-10 rounded-lg flex items-center justify-center mr-4">
                <BarChart3 className="w-6 h-6 text-royal-blue" />
              </div>

              <div className="flex-1">
                {/* Title */}
                <h2 className="text-royal-blue text-lg font-bold mb-1">
                  Manager
                </h2>

                {/* Description */}
                <p className="text-midnight-green text-sm leading-relaxed">
                  Define required info, review logs, manage alerts
                </p>
              </div>
            </div>

            {/* Button */}
            <button
              onClick={handleManagerRole}
              className="w-full bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-all duration-200 shadow-sm"
            >
              Continue as Manager
            </button>
          </div>

          {/* Staff Card */}
          <div className="bg-white border border-platinum rounded-2xl p-6 shadow-sm hover:shadow-md transition-all duration-200">
            <div className="flex items-center mb-4">
              {/* Icon */}
              <div className="w-12 h-12 bg-royal-blue bg-opacity-10 rounded-lg flex items-center justify-center mr-4">
                <Mic className="w-6 h-6 text-royal-blue" />
              </div>

              <div className="flex-1">
                {/* Title */}
                <h2 className="text-royal-blue text-lg font-bold mb-1">
                  Staff
                </h2>

                {/* Description */}
                <p className="text-midnight-green text-sm leading-relaxed">
                  Log tasks by voice, confirm details, follow requirements
                </p>
              </div>
            </div>

            {/* Button */}
            <button
              onClick={handleStaffRole}
              className="w-full bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-all duration-200 shadow-sm"
            >
              Continue as Staff
            </button>
          </div>
        </div>

        {/* Additional Info */}
        <div className="text-center mt-6">
          <p className="text-midnight-green text-xs">
            You can change your role anytime in settings
          </p>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-midnight-green px-4 py-4">
        <div className="text-center">
          <div className="text-white text-xs">
            © 2025 EchoAudit – Smart Voice Logging
          </div>
        </div>
      </footer>
    </div>
  );
}
