import {
  ChevronDown,
  Mic,
  User,
  Home,
  AlertTriangle,
  FileText,
  Users,
} from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const navigate = useNavigate();

  const handleStartVoiceLog = () => {
    navigate("/voice-input");
  };

  const handleViewAlerts = () => {
    navigate("/alerts");
  };

  const handleViewLogs = () => {
    navigate("/logs");
  };

  const handleViewSettings = () => {
    navigate("/settings");
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto">
      {/* 1️⃣ Top Bar (Header) */}
      <header className="bg-royal-blue px-4 py-3 flex items-center justify-between">
        {/* Left: App logo in Gold */}
        <div className="w-8 h-8 bg-gold rounded-full flex items-center justify-center">
          <div className="text-sm font-bold text-royal-blue">EA</div>
        </div>

        {/* Center: "EchoAudit" text */}
        <h1 className="text-white text-lg font-bold">EchoAudit</h1>

        {/* Right: User profile icon */}
        <div className="w-8 h-8 rounded-full border-2 border-platinum bg-white flex items-center justify-center">
          <User className="w-5 h-5 text-royal-blue" />
        </div>
      </header>

      {/* 2️⃣ Filters Row */}
      <div className="bg-white border-b border-platinum px-4 py-3">
        <div className="grid grid-cols-2 gap-3">
          <button className="flex items-center justify-between px-3 py-2 bg-white border border-platinum rounded-lg shadow-sm">
            <span className="text-midnight-green text-sm font-medium">
              Date Filter
            </span>
            <ChevronDown className="w-4 h-4 text-gold" />
          </button>
          <button className="flex items-center justify-between px-3 py-2 bg-white border border-platinum rounded-lg shadow-sm">
            <span className="text-midnight-green text-sm font-medium">
              Category
            </span>
            <ChevronDown className="w-4 h-4 text-gold" />
          </button>
        </div>
      </div>

      {/* 3️⃣ Main Card with Mic Button */}
      <div className="px-4 py-6">
        <div
          onClick={handleStartVoiceLog}
          className="bg-white rounded-2xl p-6 shadow-lg cursor-pointer hover:shadow-xl transition-all duration-200"
        >
          <div className="flex flex-col items-center">
            <button className="w-20 h-20 bg-gold rounded-full flex items-center justify-center shadow-lg hover:bg-yellow-400 transition-all duration-200 transform hover:scale-105">
              <Mic className="w-8 h-8 text-royal-blue" />
            </button>
            <span className="mt-4 text-midnight-green font-bold text-base">
              Start Voice Log
            </span>
          </div>
        </div>
      </div>

      {/* 4️⃣ Stats Panel */}
      <div className="px-4 pb-6">
        <div className="bg-platinum rounded-xl p-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white rounded-lg p-3 shadow-sm">
              <div className="text-royal-blue text-xs font-medium mb-1">
                Completion % Today
              </div>
              <div className="text-gold text-xl font-bold">85%</div>
            </div>
            <div className="bg-white rounded-lg p-3 shadow-sm">
              <div className="text-royal-blue text-xs font-medium mb-1">
                Tasks Logged Today
              </div>
              <div className="text-gold text-xl font-bold">12</div>
            </div>
          </div>
        </div>
      </div>

      {/* 5️⃣ Recent Tasks List */}
      <div className="px-4 pb-6">
        <h2 className="text-royal-blue font-bold text-base mb-3">
          Recent Tasks
        </h2>
        <div className="bg-white rounded-xl overflow-hidden shadow-sm">
          <div className="divide-y divide-platinum">
            {[
              { name: "Safety Check - Floor 2", time: "2:30 PM" },
              { name: "Equipment Audit", time: "1:15 PM" },
              { name: "Compliance Review", time: "11:45 AM" },
              { name: "Temperature Log", time: "10:20 AM" },
            ].map((task, index) => (
              <div
                key={index}
                className="px-4 py-3 flex justify-between items-center"
              >
                <span className="text-midnight-green text-sm font-medium">
                  {task.name}
                </span>
                <span className="text-platinum text-xs">{task.time}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 6️⃣ Alerts List */}
      <div className="px-4 pb-6 flex-1">
        <button
          onClick={handleViewAlerts}
          className="text-royal-blue font-bold text-base mb-3 hover:text-midnight-green transition-colors"
        >
          Alerts →
        </button>
        <div className="space-y-2">
          {/* High Priority Alert */}
          <div className="bg-gold rounded-lg p-3 shadow-sm">
            <div className="flex items-center">
              <AlertTriangle className="w-4 h-4 text-royal-blue mr-2" />
              <span className="text-royal-blue text-sm font-medium">
                Critical: Gas leak detected
              </span>
            </div>
          </div>

          {/* Medium Priority Alert */}
          <div className="bg-platinum rounded-lg p-3 shadow-sm">
            <div className="flex items-center">
              <AlertTriangle className="w-4 h-4 text-midnight-green mr-2" />
              <span className="text-midnight-green text-sm font-medium">
                Temperature above threshold
              </span>
            </div>
          </div>

          {/* Low Priority Alert */}
          <div className="bg-white border border-platinum rounded-lg p-3 shadow-sm">
            <div className="flex items-center">
              <AlertTriangle className="w-4 h-4 text-platinum mr-2" />
              <span className="text-midnight-green text-sm font-medium">
                Scheduled maintenance due
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 7️⃣ Bottom Navigation */}
      <nav className="bg-royal-blue px-4 py-3 mt-auto">
        <div className="grid grid-cols-4 gap-1">
          <button className="flex flex-col items-center py-2">
            <Home className="w-5 h-5 text-gold mb-1" />
            <span className="text-gold text-xs font-medium">Dashboard</span>
          </button>
          <button
            onClick={handleViewAlerts}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <AlertTriangle className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Alerts</span>
          </button>
          <button
            onClick={handleViewLogs}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <FileText className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Logs</span>
          </button>
          <button
            onClick={handleViewSettings}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <Users className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Profile</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
