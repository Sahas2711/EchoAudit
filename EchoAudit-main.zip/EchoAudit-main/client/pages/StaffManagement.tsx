import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Plus,
  Edit,
  RotateCcw,
  Ban,
  Home,
  Bell,
  FileText,
  User,
  X,
  ChevronDown,
  Mic,
  MicOff,
} from "lucide-react";

interface Staff {
  id: string;
  name: string;
  email: string;
  staffId: string;
  role: "Nurse" | "Technician" | "Auditor" | "Field Staff";
  status: "active" | "inactive";
  avatar?: string;
}

export default function StaffManagement() {
  const navigate = useNavigate();

  const [staff, setStaff] = useState<Staff[]>([
    {
      id: "1",
      name: "Dr. Sarah Johnson",
      email: "sarah.johnson@hospital.com",
      staffId: "ST001",
      role: "Nurse",
      status: "active",
    },
    {
      id: "2",
      name: "Mike Chen",
      email: "mike.chen@hospital.com",
      staffId: "ST002",
      role: "Technician",
      status: "active",
    },
    {
      id: "3",
      name: "Jessica Williams",
      email: "jessica.williams@hospital.com",
      staffId: "ST003",
      role: "Auditor",
      status: "inactive",
    },
    {
      id: "4",
      name: "Robert Taylor",
      email: "robert.taylor@hospital.com",
      staffId: "ST004",
      role: "Field Staff",
      status: "active",
    },
    {
      id: "5",
      name: "Emily Davis",
      email: "emily.davis@hospital.com",
      staffId: "ST005",
      role: "Nurse",
      status: "active",
    },
  ]);

  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState<Staff | null>(null);

  // Voice command states
  const [isListening, setIsListening] = useState(false);
  const [voiceText, setVoiceText] = useState("");
  const [showVoiceConfirmation, setShowVoiceConfirmation] = useState(false);
  const [voiceCommand, setVoiceCommand] = useState("");
  const [voiceCommandTarget, setVoiceCommandTarget] = useState<Staff | null>(
    null,
  );

  const [newStaff, setNewStaff] = useState({
    name: "",
    email: "",
    staffId: "",
    role: "Nurse" as Staff["role"],
    tempPassword: "",
  });

  const roles: Staff["role"][] = [
    "Nurse",
    "Technician",
    "Auditor",
    "Field Staff",
  ];

  const handleBack = () => {
    navigate("/manager-dashboard");
  };

  // Voice command handlers
  const handleVoiceCommand = () => {
    setIsListening(!isListening);
    if (!isListening) {
      setVoiceText("Listening...");
      // Simulate voice recognition
      setTimeout(() => {
        const sampleCommands = [
          "Add staff John Doe email john@hospital.com role Nurse",
          "Edit Sarah Johnson role to Technician",
          "Reset password for ST001",
          "Deactivate staff ID ST003",
        ];
        const randomCommand =
          sampleCommands[Math.floor(Math.random() * sampleCommands.length)];
        setVoiceText(randomCommand);
        setVoiceCommand(randomCommand);
        processVoiceCommand(randomCommand);
      }, 2000);
    } else {
      setVoiceText("");
      setVoiceCommand("");
    }
  };

  const processVoiceCommand = (command: string) => {
    const lowerCommand = command.toLowerCase();

    if (lowerCommand.includes("add staff")) {
      setShowVoiceConfirmation(true);
      setVoiceCommand(`Add new staff member: ${command}`);
    } else if (lowerCommand.includes("edit") && lowerCommand.includes("role")) {
      const staffName = extractStaffName(command);
      const targetStaff = staff.find((s) =>
        s.name.toLowerCase().includes(staffName.toLowerCase()),
      );
      if (targetStaff) {
        setVoiceCommandTarget(targetStaff);
        setShowVoiceConfirmation(true);
        setVoiceCommand(`Edit ${targetStaff.name}'s role: ${command}`);
      }
    } else if (lowerCommand.includes("reset password")) {
      const staffId = extractStaffId(command);
      const targetStaff = staff.find(
        (s) =>
          s.staffId === staffId ||
          s.name.toLowerCase().includes(staffId.toLowerCase()),
      );
      if (targetStaff) {
        setVoiceCommandTarget(targetStaff);
        setShowVoiceConfirmation(true);
        setVoiceCommand(`Reset password for ${targetStaff.name}: ${command}`);
      }
    } else if (lowerCommand.includes("deactivate")) {
      const staffId = extractStaffId(command);
      const targetStaff = staff.find((s) => s.staffId === staffId);
      if (targetStaff) {
        setVoiceCommandTarget(targetStaff);
        setShowVoiceConfirmation(true);
        setVoiceCommand(`Deactivate ${targetStaff.name}: ${command}`);
      }
    }
    setIsListening(false);
  };

  const extractStaffName = (command: string) => {
    const words = command.split(" ");
    const editIndex = words.findIndex((w) => w.toLowerCase() === "edit");
    if (editIndex >= 0 && editIndex + 1 < words.length) {
      return words[editIndex + 1];
    }
    return "";
  };

  const extractStaffId = (command: string) => {
    const match = command.match(/ST\d+/i) || command.match(/\b\w+\s+\w+\b/);
    return match ? match[0] : "";
  };

  const confirmVoiceCommand = () => {
    if (voiceCommand.toLowerCase().includes("add staff")) {
      handleAddStaff();
    } else if (
      voiceCommand.toLowerCase().includes("edit") &&
      voiceCommandTarget
    ) {
      handleEditStaff(voiceCommandTarget);
    } else if (
      voiceCommand.toLowerCase().includes("reset password") &&
      voiceCommandTarget
    ) {
      handleResetPassword(voiceCommandTarget.id);
    } else if (
      voiceCommand.toLowerCase().includes("deactivate") &&
      voiceCommandTarget
    ) {
      handleDeactivateStaff(voiceCommandTarget.id);
    }
    setShowVoiceConfirmation(false);
    setVoiceCommand("");
    setVoiceCommandTarget(null);
  };

  const handleAddStaff = () => {
    const tempPassword = Math.random().toString(36).slice(-8);
    setNewStaff((prev) => ({ ...prev, tempPassword }));
    setShowAddModal(true);
  };

  const handleEditStaff = (staffMember: Staff) => {
    setSelectedStaff(staffMember);
    setShowEditModal(true);
  };

  const handleResetPassword = (staffId: string) => {
    const tempPassword = Math.random().toString(36).slice(-8);
    console.log(`Reset password for ${staffId}: ${tempPassword}`);
    // In a real app, this would send an email with the new password
    alert(
      `Temporary password generated: ${tempPassword}\nUser will be required to change on next login.`,
    );
  };

  const handleDeactivateStaff = (staffId: string) => {
    setStaff((prev) =>
      prev.map((s) =>
        s.id === staffId
          ? { ...s, status: s.status === "active" ? "inactive" : "active" }
          : s,
      ),
    );
  };

  const saveNewStaff = () => {
    if (newStaff.name && newStaff.email && newStaff.staffId) {
      const newStaffMember: Staff = {
        id: Date.now().toString(),
        name: newStaff.name,
        email: newStaff.email,
        staffId: newStaff.staffId,
        role: newStaff.role,
        status: "active",
      };
      setStaff((prev) => [...prev, newStaffMember]);
      setNewStaff({
        name: "",
        email: "",
        staffId: "",
        role: "Nurse",
        tempPassword: "",
      });
      setShowAddModal(false);
    }
  };

  const saveEditedStaff = () => {
    if (selectedStaff) {
      setStaff((prev) =>
        prev.map((s) => (s.id === selectedStaff.id ? selectedStaff : s)),
      );
      setShowEditModal(false);
      setSelectedStaff(null);
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "Nurse":
        return "bg-blue-100 text-blue-800";
      case "Technician":
        return "bg-green-100 text-green-800";
      case "Auditor":
        return "bg-purple-100 text-purple-800";
      case "Field Staff":
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col max-w-md mx-auto">
      {/* 1️⃣ Header */}
      <header className="bg-royal-blue px-4 py-3 flex items-center justify-between">
        {/* Left: Back Arrow */}
        <button
          onClick={handleBack}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>

        {/* Center: Title */}
        <h1 className="text-white text-lg font-bold">Staff Management</h1>

        {/* Right: Add Staff Icon */}
        <button
          onClick={handleAddStaff}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <Plus className="w-5 h-5 text-gold" />
        </button>
      </header>

      {/* Voice Command Bar */}
      <div className="bg-royal-blue bg-opacity-90 px-4 py-2 border-t border-gold border-opacity-30">
        <div className="flex items-center space-x-3">
          <button
            onClick={handleVoiceCommand}
            className={`w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${
              isListening
                ? "bg-gold animate-pulse shadow-lg shadow-gold/50"
                : "bg-gold hover:bg-yellow-400"
            }`}
          >
            {isListening ? (
              <MicOff className="w-4 h-4 text-royal-blue" />
            ) : (
              <Mic className="w-4 h-4 text-royal-blue" />
            )}
          </button>

          <div className="flex-1">
            {voiceText ? (
              <div className="text-white text-sm">
                {isListening ? (
                  <span className="animate-pulse">🎤 {voiceText}</span>
                ) : (
                  <span className="text-gold">"{voiceText}"</span>
                )}
              </div>
            ) : (
              <div className="text-platinum text-xs">
                Say: "Add Staff", "Edit Staff", "Reset Password"...
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 2️⃣ Staff List Section */}
      <div className="flex-1 bg-gray-100 px-4 py-4 space-y-3 overflow-y-auto">
        {staff.map((staffMember) => (
          <div
            key={staffMember.id}
            className="bg-white border border-platinum rounded-lg p-4 shadow-sm"
          >
            {/* Top Row: Avatar, Name, Role Badge */}
            <div className="flex items-center mb-3">
              {/* Profile Avatar */}
              <div className="w-12 h-12 rounded-full bg-royal-blue text-white flex items-center justify-center font-bold text-sm mr-3">
                {getInitials(staffMember.name)}
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <span className="text-royal-blue font-bold text-sm">
                      {staffMember.name}
                    </span>
                    <button
                      onClick={() => {
                        setVoiceCommandTarget(staffMember);
                        handleVoiceCommand();
                      }}
                      className="ml-2 w-5 h-5 rounded-full bg-gold bg-opacity-20 hover:bg-opacity-40 flex items-center justify-center transition-colors"
                      title="Voice commands for this staff member"
                    >
                      <Mic className="w-3 h-3 text-gold" />
                    </button>
                  </div>
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-medium ${getRoleBadgeColor(staffMember.role)}`}
                  >
                    {staffMember.role}
                  </span>
                </div>
              </div>
            </div>

            {/* Middle Row: Email/Staff ID, Status */}
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-platinum text-xs">{staffMember.email}</div>
                <div className="text-platinum text-xs">
                  ID: {staffMember.staffId}
                </div>
              </div>
              <div className="flex items-center">
                <div
                  className={`w-2 h-2 rounded-full mr-2 ${
                    staffMember.status === "active"
                      ? "bg-green-500"
                      : "bg-red-500"
                  }`}
                ></div>
                <span
                  className={`text-xs font-medium ${
                    staffMember.status === "active"
                      ? "text-green-600"
                      : "text-red-600"
                  }`}
                >
                  {staffMember.status === "active" ? "Active" : "Deactivated"}
                </span>
              </div>
            </div>

            {/* Bottom Row: Action Buttons */}
            <div className="flex space-x-2">
              <button
                onClick={() => handleEditStaff(staffMember)}
                className="flex-1 bg-white border border-platinum text-royal-blue text-xs font-medium py-2 px-3 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center"
              >
                <Edit className="w-3 h-3 mr-1" />
                Edit
              </button>

              <button
                onClick={() => handleResetPassword(staffMember.id)}
                className="flex-1 bg-gold text-royal-blue text-xs font-medium py-2 px-3 rounded-lg hover:bg-yellow-400 transition-colors flex items-center justify-center"
              >
                <RotateCcw className="w-3 h-3 mr-1" />
                Reset Password
              </button>

              <button
                onClick={() => handleDeactivateStaff(staffMember.id)}
                className={`flex-1 text-xs font-medium py-2 px-3 rounded-lg transition-colors flex items-center justify-center ${
                  staffMember.status === "active"
                    ? "text-red-600 hover:bg-red-50"
                    : "text-green-600 hover:bg-green-50"
                }`}
              >
                <Ban className="w-3 h-3 mr-1" />
                {staffMember.status === "active" ? "Deactivate" : "Activate"}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* 5️⃣ Footer Navigation */}
      <nav className="bg-royal-blue px-4 py-3">
        <div className="grid grid-cols-4 gap-1">
          <button
            onClick={() => navigate("/manager-dashboard")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <Home className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Dashboard</span>
          </button>

          <button
            onClick={() => navigate("/alerts")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <Bell className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Alerts</span>
          </button>

          <button
            onClick={() => navigate("/staff-logs")}
            className="flex flex-col items-center py-2"
          >
            <FileText className="w-5 h-5 text-gold mb-1" />
            <span className="text-gold text-xs font-medium">Logs</span>
          </button>

          <button
            onClick={() => navigate("/settings")}
            className="flex flex-col items-center py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition-colors"
          >
            <User className="w-5 h-5 text-white mb-1" />
            <span className="text-white text-xs">Profile</span>
          </button>
        </div>
      </nav>

      {/* 4️⃣ Add Staff Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-royal-blue font-bold text-lg">
                Add New Staff
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-platinum hover:text-midnight-green"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-midnight-green text-sm font-medium mb-2 block">
                  Full Name
                </label>
                <input
                  type="text"
                  value={newStaff.name}
                  onChange={(e) =>
                    setNewStaff((prev) => ({ ...prev, name: e.target.value }))
                  }
                  className="w-full px-3 py-2 border border-platinum rounded-lg focus:outline-none focus:ring-2 focus:ring-gold"
                  placeholder="Enter full name"
                />
              </div>

              <div>
                <label className="text-midnight-green text-sm font-medium mb-2 block">
                  Email
                </label>
                <input
                  type="email"
                  value={newStaff.email}
                  onChange={(e) =>
                    setNewStaff((prev) => ({ ...prev, email: e.target.value }))
                  }
                  className="w-full px-3 py-2 border border-platinum rounded-lg focus:outline-none focus:ring-2 focus:ring-gold"
                  placeholder="Enter email address"
                />
              </div>

              <div>
                <label className="text-midnight-green text-sm font-medium mb-2 block">
                  Staff ID
                </label>
                <input
                  type="text"
                  value={newStaff.staffId}
                  onChange={(e) =>
                    setNewStaff((prev) => ({
                      ...prev,
                      staffId: e.target.value,
                    }))
                  }
                  className="w-full px-3 py-2 border border-platinum rounded-lg focus:outline-none focus:ring-2 focus:ring-gold"
                  placeholder="Enter staff ID"
                />
              </div>

              <div>
                <label className="text-midnight-green text-sm font-medium mb-2 block">
                  Role
                </label>
                <div className="relative">
                  <select
                    value={newStaff.role}
                    onChange={(e) =>
                      setNewStaff((prev) => ({
                        ...prev,
                        role: e.target.value as Staff["role"],
                      }))
                    }
                    className="w-full px-3 py-2 border border-platinum rounded-lg focus:outline-none focus:ring-2 focus:ring-gold appearance-none cursor-pointer"
                  >
                    {roles.map((role) => (
                      <option key={role} value={role}>
                        {role}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-midnight-green pointer-events-none" />
                </div>
              </div>

              <div>
                <label className="text-midnight-green text-sm font-medium mb-2 block">
                  Temporary Password
                </label>
                <input
                  type="text"
                  value={newStaff.tempPassword}
                  onChange={(e) =>
                    setNewStaff((prev) => ({
                      ...prev,
                      tempPassword: e.target.value,
                    }))
                  }
                  className="w-full px-3 py-2 border border-platinum rounded-lg focus:outline-none focus:ring-2 focus:ring-gold"
                  placeholder="Auto-generated password"
                />
                <p className="text-xs text-platinum mt-1">
                  Staff will be required to change password on first login
                </p>
              </div>
            </div>

            <div className="flex space-x-3 mt-6">
              <button
                onClick={() => setShowAddModal(false)}
                className="flex-1 bg-white border border-platinum text-midnight-green font-medium py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>

              <button
                onClick={saveNewStaff}
                disabled={
                  !newStaff.name || !newStaff.email || !newStaff.staffId
                }
                className="flex-1 bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3️⃣ Edit Staff Modal */}
      {showEditModal && selectedStaff && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-royal-blue font-bold text-lg">
                {selectedStaff.name}
              </h3>
              <button
                onClick={() => setShowEditModal(false)}
                className="text-platinum hover:text-midnight-green"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-midnight-green text-sm font-medium mb-2 block">
                  Role
                </label>
                <div className="relative">
                  <select
                    value={selectedStaff.role}
                    onChange={(e) =>
                      setSelectedStaff((prev) =>
                        prev
                          ? { ...prev, role: e.target.value as Staff["role"] }
                          : null,
                      )
                    }
                    className="w-full px-3 py-2 border border-platinum rounded-lg focus:outline-none focus:ring-2 focus:ring-gold appearance-none cursor-pointer"
                  >
                    {roles.map((role) => (
                      <option key={role} value={role}>
                        {role}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-midnight-green pointer-events-none" />
                </div>
              </div>

              <div>
                <label className="text-midnight-green text-sm font-medium mb-2 block">
                  Status
                </label>
                <div className="flex items-center">
                  <button
                    onClick={() =>
                      setSelectedStaff((prev) =>
                        prev
                          ? {
                              ...prev,
                              status:
                                prev.status === "active"
                                  ? "inactive"
                                  : "active",
                            }
                          : null,
                      )
                    }
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      selectedStaff.status === "active"
                        ? "bg-gold"
                        : "bg-platinum"
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                        selectedStaff.status === "active"
                          ? "translate-x-6"
                          : "translate-x-1"
                      }`}
                    />
                  </button>
                  <span className="ml-3 text-sm text-midnight-green">
                    {selectedStaff.status === "active" ? "Active" : "Inactive"}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex space-x-3 mt-6">
              <button
                onClick={() => setShowEditModal(false)}
                className="flex-1 bg-white border border-platinum text-midnight-green font-medium py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>

              <button
                onClick={saveEditedStaff}
                className="flex-1 bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Mic Button */}
      <button
        onClick={handleVoiceCommand}
        className={`fixed bottom-20 right-4 w-14 h-14 rounded-full flex items-center justify-center z-40 transition-all duration-300 shadow-lg ${
          isListening
            ? "bg-gold animate-pulse shadow-gold/50 scale-110"
            : "bg-gold hover:bg-yellow-400 hover:scale-105"
        }`}
      >
        {isListening ? (
          <div className="relative">
            <MicOff className="w-6 h-6 text-royal-blue" />
            <div className="absolute inset-0 rounded-full border-2 border-royal-blue animate-ping"></div>
          </div>
        ) : (
          <Mic className="w-6 h-6 text-royal-blue" />
        )}
      </button>

      {/* Voice Command Overlay */}
      {isListening && (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 m-4 max-w-sm w-full">
            <div className="text-center">
              <div className="w-16 h-16 bg-gold rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                <Mic className="w-8 h-8 text-royal-blue" />
              </div>
              <h3 className="text-royal-blue font-bold text-lg mb-2">
                Listening...
              </h3>
              <div className="text-midnight-green text-sm mb-4">
                {voiceText || "Speak your command"}
              </div>
              <div className="text-xs text-platinum">
                Try: "Add staff John Doe", "Edit Sarah's role", "Reset password
                for ST001"
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Voice Command Confirmation */}
      {showVoiceConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
            <div className="text-center mb-4">
              <div className="w-12 h-12 bg-royal-blue rounded-full flex items-center justify-center mx-auto mb-3">
                <Mic className="w-6 h-6 text-gold" />
              </div>
              <h3 className="text-royal-blue font-bold text-lg mb-2">
                Voice Command
              </h3>
            </div>

            <div className="bg-royal-blue bg-opacity-10 rounded-lg p-3 mb-4">
              <div className="text-royal-blue text-sm font-medium">
                {voiceCommand}
              </div>
            </div>

            {voiceCommandTarget && (
              <div className="bg-platinum bg-opacity-50 rounded-lg p-3 mb-4">
                <div className="text-midnight-green text-sm">
                  Target:{" "}
                  <span className="font-medium">{voiceCommandTarget.name}</span>{" "}
                  ({voiceCommandTarget.staffId})
                </div>
              </div>
            )}

            <div className="text-center text-xs text-platinum mb-4">
              Confirm this action?
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => {
                  setShowVoiceConfirmation(false);
                  setVoiceCommand("");
                  setVoiceCommandTarget(null);
                }}
                className="flex-1 bg-white border border-platinum text-midnight-green font-medium py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>

              <button
                onClick={confirmVoiceCommand}
                className="flex-1 bg-gold text-royal-blue font-bold py-3 px-4 rounded-lg hover:bg-yellow-400 transition-colors"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
