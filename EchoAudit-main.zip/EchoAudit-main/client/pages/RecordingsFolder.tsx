import { useState, useEffect } from "react";
import { recordingManager, RecordingInfo } from "../lib/recordingManager";
import { Play, Download, Trash2, FolderOpen, FileAudio } from "lucide-react";

export default function RecordingsFolder() {
  const [recordings, setRecordings] = useState<RecordingInfo[]>([]);
  const [selectedRecording, setSelectedRecording] = useState<RecordingInfo | null>(null);
  const [isPlaying, setIsPlaying] = useState<string | null>(null);
  const [stats, setStats] = useState<{ count: number; totalSize: number; averageSize: number; folderPath?: string }>({ count: 0, totalSize: 0, averageSize: 0 });

  useEffect(() => {
    loadRecordings();
  }, []);

  const loadRecordings = async () => {
    try {
      const allRecordings = await recordingManager.getRecordings();
      setRecordings(allRecordings);
      const statsData = await recordingManager.getStorageStats();
      setStats(statsData);
    } catch (error) {
      console.error('Failed to load recordings:', error);
    }
  };

  const handlePlay = async (recording: RecordingInfo) => {
    try {
      setIsPlaying(recording.id);
      await recordingManager.playRecording(recording.id);
    } catch (error) {
      console.error('Failed to play recording:', error);
      alert('Failed to play recording');
    } finally {
      setIsPlaying(null);
    }
  };

  const handleDownload = (recording: RecordingInfo) => {
    const success = recordingManager.downloadRecording(recording.id);
    if (!success) {
      alert('Failed to download recording');
    }
  };

  const handleDelete = async (recording: RecordingInfo) => {
    if (confirm(`Are you sure you want to delete "${recording.filename}"?`)) {
      const success = await recordingManager.deleteRecording(recording.id);
      if (success) {
        loadRecordings();
      } else {
        alert('Failed to delete recording');
      }
    }
  };

  const handleExportAll = async () => {
    try {
      await recordingManager.exportAllRecordings();
    } catch (error) {
      console.error('Failed to export recordings:', error);
      alert('Failed to export recordings');
    }
  };

  const handleClearAll = async () => {
    if (confirm('Are you sure you want to delete all recordings? This cannot be undone.')) {
      await recordingManager.clearAllRecordings();
      loadRecordings();
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (date: Date): string => {
    return date.toLocaleString();
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <FolderOpen className="w-8 h-8 text-blue-500" />
              <h1 className="text-3xl font-bold">Recordings Folder</h1>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={handleExportAll}
                disabled={recordings.length === 0}
                className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                <Download className="w-4 h-4" />
                <span>Export All</span>
              </button>
              <button
                onClick={handleClearAll}
                disabled={recordings.length === 0}
                className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                <Trash2 className="w-4 h-4" />
                <span>Clear All</span>
              </button>
            </div>
          </div>

          {/* Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{stats.count}</div>
              <div className="text-sm text-gray-600">Total Recordings</div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{formatFileSize(stats.totalSize)}</div>
              <div className="text-sm text-gray-600">Total Size</div>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{formatFileSize(stats.averageSize)}</div>
              <div className="text-sm text-gray-600">Average Size</div>
            </div>
          </div>
        </div>

        {/* Recordings List */}
        <div className="bg-white rounded-lg shadow-lg">
          {recordings.length === 0 ? (
            <div className="p-12 text-center">
              <FileAudio className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No Recordings Found</h3>
              <p className="text-gray-500">Start recording audio to see your recordings here.</p>
            </div>
          ) : (
            <div className="overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Recording
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Size
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {recordings.map((recording) => (
                    <tr key={recording.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <FileAudio className="w-5 h-5 text-blue-500 mr-3" />
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {recording.filename}
                            </div>
                            <div className="text-sm text-gray-500">
                              ID: {recording.id}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {formatFileSize(recording.size)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {recording.type}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {formatDate(recording.timestamp)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handlePlay(recording)}
                            disabled={isPlaying === recording.id}
                            className="text-blue-600 hover:text-blue-900 disabled:opacity-50 disabled:cursor-not-allowed"
                            title="Play"
                          >
                            <Play className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDownload(recording)}
                            className="text-green-600 hover:text-green-900"
                            title="Download"
                          >
                            <Download className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(recording)}
                            className="text-red-600 hover:text-red-900"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
} 