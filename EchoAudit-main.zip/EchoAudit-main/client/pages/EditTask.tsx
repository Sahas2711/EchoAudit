import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ArrowLeft,
  Calendar,
  Clock,
  MapPin,
  User,
  Tag,
  AlertTriangle,
  ChevronDown,
} from "lucide-react";

export default function EditTask() {
  const navigate = useNavigate();

  const [taskData, setTaskData] = useState({
    taskName: "Check oxygen supply in Ward B",
    description:
      "Routine inspection of oxygen supply systems and pressure levels in Ward B patient rooms",
    location: "Ward B - Room 205",
    date: "2025-08-13",
    time: "14:35",
    assignedTo: "",
    category: "Healthcare",
    priority: "",
    status: "pending",
  });

  const [missingFields] = useState({
    assignedTo: "required",
    priority: "optional",
  });

  const handleBack = () => {
    navigate("/task-confirmation");
  };

  const handleSave = () => {
    console.log("Saving task:", taskData);
    // In a real app, this would save to the database
    navigate("/logs");
  };

  const handleCancel = () => {
    navigate("/dashboard");
  };

  const handleInputChange = (field: string, value: string) => {
    setTaskData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const getFieldBackground = (fieldName: string) => {
    if (missingFields[fieldName as keyof typeof missingFields]) {
      return missingFields[fieldName as keyof typeof missingFields] ===
        "required"
        ? "bg-red-50 border-red-200"
        : "bg-yellow-50 border-yellow-200";
    }
    return "bg-white border-platinum";
  };

  const locations = [
    "Ward A - Room 101",
    "Ward B - Room 205",
    "ICU - Room 301",
    "Operating Room 1",
    "Operating Room 2",
    "Emergency Department",
    "Laboratory",
    "Pharmacy",
  ];

  const assignees = [
    "Dr. Smith",
    "Nurse Johnson",
    "Tech Team",
    "Safety Officer",
    "Maintenance Staff",
    "Emergency Team",
  ];

  const categories = [
    "Healthcare",
    "Safety",
    "Maintenance",
    "Security",
    "Compliance",
    "Emergency",
  ];

  const priorities = ["Low", "Medium", "High"];

  const statuses = ["pending", "in-progress", "completed", "cancelled"];

  return (
    <div className="min-h-screen bg-platinum flex flex-col max-w-md mx-auto">
      {/* 1. Header */}
      <header className="bg-royal-blue px-4 py-3 flex items-center justify-between h-14">
        {/* Back Icon */}
        <button
          onClick={handleBack}
          className="w-8 h-8 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded-full transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>

        {/* Title */}
        <h1 className="text-gold text-lg font-bold">Edit Task</h1>

        {/* Spacer for balance */}
        <div className="w-8"></div>
      </header>

      {/* Content */}
      <div className="flex-1 px-4 py-6">
        {/* 2. Main Form Card */}
        <div className="bg-white rounded-xl p-5 shadow-lg">
          <form className="space-y-5">
            {/* Task Name */}
            <div>
              <label className="text-midnight-green text-sm font-medium mb-2 block">
                Task Name
              </label>
              <input
                type="text"
                value={taskData.taskName}
                onChange={(e) => handleInputChange("taskName", e.target.value)}
                className={`w-full px-3 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent text-midnight-green ${getFieldBackground("taskName")}`}
                placeholder="Enter task name"
              />
            </div>

            {/* Description */}
            <div>
              <label className="text-midnight-green text-sm font-medium mb-2 block">
                Description
              </label>
              <textarea
                value={taskData.description}
                onChange={(e) =>
                  handleInputChange("description", e.target.value)
                }
                rows={3}
                className={`w-full px-3 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent text-midnight-green resize-none ${getFieldBackground("description")}`}
                placeholder="Enter task description"
              />
            </div>

            {/* Location */}
            <div>
              <label className="text-midnight-green text-sm font-medium mb-2 block">
                <MapPin className="w-4 h-4 inline mr-1" />
                Location
              </label>
              <div className="relative">
                <select
                  value={taskData.location}
                  onChange={(e) =>
                    handleInputChange("location", e.target.value)
                  }
                  className={`w-full px-3 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent text-midnight-green appearance-none cursor-pointer ${getFieldBackground("location")}`}
                >
                  {locations.map((location) => (
                    <option key={location} value={location}>
                      {location}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-midnight-green pointer-events-none" />
              </div>
            </div>

            {/* Date & Time */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-midnight-green text-sm font-medium mb-2 block">
                  <Calendar className="w-4 h-4 inline mr-1" />
                  Date
                </label>
                <input
                  type="date"
                  value={taskData.date}
                  onChange={(e) => handleInputChange("date", e.target.value)}
                  className={`w-full px-3 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent text-midnight-green ${getFieldBackground("date")}`}
                />
              </div>
              <div>
                <label className="text-midnight-green text-sm font-medium mb-2 block">
                  <Clock className="w-4 h-4 inline mr-1" />
                  Time
                </label>
                <input
                  type="time"
                  value={taskData.time}
                  onChange={(e) => handleInputChange("time", e.target.value)}
                  className={`w-full px-3 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent text-midnight-green ${getFieldBackground("time")}`}
                />
              </div>
            </div>

            {/* Assigned To */}
            <div>
              <label className="text-midnight-green text-sm font-medium mb-2 block">
                <User className="w-4 h-4 inline mr-1" />
                Assigned To
                {missingFields.assignedTo === "required" && (
                  <span className="text-red-500 ml-1">*</span>
                )}
              </label>
              <div className="relative">
                <select
                  value={taskData.assignedTo}
                  onChange={(e) =>
                    handleInputChange("assignedTo", e.target.value)
                  }
                  className={`w-full px-3 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent text-midnight-green appearance-none cursor-pointer ${getFieldBackground("assignedTo")}`}
                >
                  <option value="">Select assignee</option>
                  {assignees.map((assignee) => (
                    <option key={assignee} value={assignee}>
                      {assignee}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-midnight-green pointer-events-none" />
              </div>
              {missingFields.assignedTo === "required" && (
                <div className="flex items-center mt-1">
                  <AlertTriangle className="w-3 h-3 text-red-500 mr-1" />
                  <span className="text-red-500 text-xs">
                    This field is required
                  </span>
                </div>
              )}
            </div>

            {/* Category */}
            <div>
              <label className="text-midnight-green text-sm font-medium mb-2 block">
                <Tag className="w-4 h-4 inline mr-1" />
                Category
              </label>
              <div className="relative">
                <select
                  value={taskData.category}
                  onChange={(e) =>
                    handleInputChange("category", e.target.value)
                  }
                  className={`w-full px-3 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent text-midnight-green appearance-none cursor-pointer ${getFieldBackground("category")}`}
                >
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-midnight-green pointer-events-none" />
              </div>
            </div>

            {/* Priority */}
            <div>
              <label className="text-midnight-green text-sm font-medium mb-2 block">
                Priority
                {missingFields.priority === "optional" && (
                  <span className="text-yellow-600 ml-1">(Optional)</span>
                )}
              </label>
              <div className="relative">
                <select
                  value={taskData.priority}
                  onChange={(e) =>
                    handleInputChange("priority", e.target.value)
                  }
                  className={`w-full px-3 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent text-midnight-green appearance-none cursor-pointer ${getFieldBackground("priority")}`}
                >
                  <option value="">Select priority</option>
                  {priorities.map((priority) => (
                    <option key={priority} value={priority}>
                      {priority}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-midnight-green pointer-events-none" />
              </div>
              {missingFields.priority === "optional" && (
                <div className="flex items-center mt-1">
                  <AlertTriangle className="w-3 h-3 text-yellow-600 mr-1" />
                  <span className="text-yellow-600 text-xs">
                    Consider setting a priority for better organization
                  </span>
                </div>
              )}
            </div>

            {/* Status */}
            <div>
              <label className="text-midnight-green text-sm font-medium mb-2 block">
                Status
              </label>
              <div className="relative">
                <select
                  value={taskData.status}
                  onChange={(e) => handleInputChange("status", e.target.value)}
                  className={`w-full px-3 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent text-midnight-green appearance-none cursor-pointer ${getFieldBackground("status")}`}
                >
                  {statuses.map((status) => (
                    <option key={status} value={status}>
                      {status.charAt(0).toUpperCase() +
                        status.slice(1).replace("-", " ")}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-midnight-green pointer-events-none" />
              </div>
            </div>
          </form>
        </div>
      </div>

      {/* 5. Action Buttons */}
      <div className="px-4 py-4 space-y-3">
        {/* Primary Button - Save Changes */}
        <button
          onClick={handleSave}
          className="w-full bg-royal-blue text-gold font-bold py-4 px-6 rounded-lg hover:bg-blue-900 transition-all duration-200 transform hover:scale-105 shadow-lg"
        >
          Save Changes
        </button>

        {/* Secondary Button - Cancel */}
        <button
          onClick={handleCancel}
          className="w-full bg-platinum text-midnight-green font-medium py-4 px-6 rounded-lg hover:bg-gray-300 transition-colors duration-200 shadow-sm"
        >
          Cancel
        </button>
      </div>
    </div>
  );
}
