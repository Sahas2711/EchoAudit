// Audio recording and conversion utilities

export interface AudioRecorder {
  start: () => Promise<void>;
  stop: () => Promise<Blob>;
  pause: () => void;
  resume: () => void;
  isRecording: () => boolean;
}

export class WebAudioRecorder implements AudioRecorder {
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private stream: MediaStream | null = null;
  private isPaused = false;
  private recordingStartTime: number = 0;

  async start(): Promise<void> {
    try {
      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('getUserMedia is not supported in this browser');
      }

      // Request microphone access with simpler constraints for better compatibility
      this.stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: { ideal: true },
          noiseSuppression: { ideal: true },
          autoGainControl: { ideal: true },
          sampleRate: { ideal: 44100, min: 22050 },
          channelCount: { ideal: 1, min: 1 },
        } 
      });
      
      console.log('Microphone access granted, stream:', this.stream);
      
      // Find the best supported MIME type
      const mimeTypes = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/mp4',
        'audio/ogg;codecs=opus',
        'audio/wav'
      ];
      
      let selectedMimeType = '';
      for (const mimeType of mimeTypes) {
        if (MediaRecorder.isTypeSupported(mimeType)) {
          selectedMimeType = mimeType;
          break;
        }
      }
      
      if (!selectedMimeType) {
        console.warn('No specific MIME type supported, using default');
      }
      
      const options: MediaRecorderOptions = selectedMimeType ? { mimeType: selectedMimeType } : {};
      
      this.mediaRecorder = new MediaRecorder(this.stream, options);
      this.audioChunks = [];
      this.recordingStartTime = Date.now();
      
      // Set up event handlers
      this.mediaRecorder.ondataavailable = (event) => {
        console.log('Audio chunk received:', event.data.size, 'bytes, type:', event.data.type);
        if (event.data.size > 0) {
          this.audioChunks.push(event.data);
        }
      };
      
      this.mediaRecorder.onstart = () => {
        console.log('MediaRecorder started successfully with MIME type:', selectedMimeType || 'default');
      };
      
      this.mediaRecorder.onerror = (event) => {
        console.error('MediaRecorder error:', event);
        throw new Error(`MediaRecorder error: ${event.error?.message || 'Unknown error'}`);
      };
      
      this.mediaRecorder.onstop = () => {
        console.log('MediaRecorder stopped, total chunks:', this.audioChunks.length);
      };
      
      // Start recording with smaller timeslice for more frequent data
      this.mediaRecorder.start(500); // Collect data every 500ms
      
    } catch (error) {
      console.error('Error starting audio recording:', error);
      
      // Clean up on error
      this.cleanup();
      
      // Provide specific error messages
      if (error instanceof DOMException) {
        switch (error.name) {
          case 'NotAllowedError':
            throw new Error('Microphone access denied. Please allow microphone permissions in your browser.');
          case 'NotFoundError':
            throw new Error('No microphone found. Please connect a microphone and try again.');
          case 'NotSupportedError':
            throw new Error('Audio recording is not supported in this browser. Try Chrome or Firefox.');
          case 'NotReadableError':
            throw new Error('Microphone is being used by another application. Please close other apps using the microphone.');
          case 'OverconstrainedError':
            throw new Error('Microphone constraints cannot be satisfied. Please check your microphone settings.');
          case 'SecurityError':
            throw new Error('Microphone access blocked by security policy. Please check your browser settings.');
          default:
            throw new Error(`Microphone error: ${error.message}`);
        }
      }
      
      throw new Error('Failed to start audio recording: ' + (error as Error).message);
    }
  }

  async stop(): Promise<Blob> {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) {
        reject(new Error('No active recording'));
        return;
      }

      if (this.mediaRecorder.state === 'inactive') {
        reject(new Error('Recording is not active'));
        return;
      }

      const recordingDuration = Date.now() - this.recordingStartTime;
      console.log(`Stopping recording after ${recordingDuration}ms`);

      // Set up one-time event handlers
      const onStop = () => {
        console.log('MediaRecorder stopped, processing audio chunks:', this.audioChunks.length);
        
        if (this.audioChunks.length === 0) {
          console.error('No audio chunks recorded');
          reject(new Error('No audio data recorded. Please try again.'));
          this.cleanup();
          return;
        }
        
        // Calculate total size
        const totalSize = this.audioChunks.reduce((sum, chunk) => sum + chunk.size, 0);
        console.log('Total audio data size:', totalSize, 'bytes');
        
        if (totalSize === 0) {
          console.error('All audio chunks are empty');
          reject(new Error('No audio data recorded. Please check your microphone.'));
          this.cleanup();
          return;
        }
        
        // Determine the correct MIME type
        let mimeType = 'audio/webm'; // default
        if (this.audioChunks.length > 0 && this.audioChunks[0].type) {
          mimeType = this.audioChunks[0].type;
        }
        
        try {
          const audioBlob = new Blob(this.audioChunks, { type: mimeType });
          console.log('Successfully created audio blob:', audioBlob.size, 'bytes, type:', audioBlob.type);
          
          this.cleanup();
          resolve(audioBlob);
        } catch (error) {
          console.error('Error creating audio blob:', error);
          reject(new Error('Failed to create audio file'));
          this.cleanup();
        }
      };

      const onError = (event: any) => {
        console.error('MediaRecorder error during stop:', event);
        reject(new Error(`Recording error: ${event.error?.message || 'Unknown error'}`));
        this.cleanup();
      };

      // Set up event handlers
      this.mediaRecorder.onstop = onStop;
      this.mediaRecorder.onerror = onError;

      try {
        this.mediaRecorder.stop();
        console.log('MediaRecorder.stop() called successfully');
      } catch (error) {
        console.error('Error calling MediaRecorder.stop():', error);
        reject(new Error('Failed to stop recording'));
        this.cleanup();
      }
    });
  }

  pause(): void {
    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      this.mediaRecorder.pause();
      this.isPaused = true;
    }
  }

  resume(): void {
    if (this.mediaRecorder && this.mediaRecorder.state === 'paused') {
      this.mediaRecorder.resume();
      this.isPaused = false;
    }
  }

  isRecording(): boolean {
    return this.mediaRecorder?.state === 'recording' || this.isPaused;
  }

  private cleanup(): void {
    console.log('Cleaning up audio recorder...');
    
    if (this.stream) {
      this.stream.getTracks().forEach(track => {
        console.log('Stopping track:', track.kind, track.label);
        track.stop();
      });
      this.stream = null;
    }
    
    if (this.mediaRecorder) {
      if (this.mediaRecorder.state !== 'inactive') {
        try {
          this.mediaRecorder.stop();
        } catch (error) {
          console.warn('Error stopping MediaRecorder during cleanup:', error);
        }
      }
      this.mediaRecorder = null;
    }
    
    this.audioChunks = [];
    this.isPaused = false;
    this.recordingStartTime = 0;
    
    console.log('Audio recorder cleanup completed');
  }
}

// Function to convert audio to MP3 using the server
export async function convertAudioToMp3(audioBlob: Blob): Promise<Blob> {
  try {
    const formData = new FormData();
    formData.append('audio', audioBlob, 'recording.webm');

    const response = await fetch('/api/audio/convert', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to convert audio');
    }

    const mp3Blob = await response.blob();
    return mp3Blob;
  } catch (error) {
    console.error('Error converting audio:', error);
    throw new Error('Failed to convert audio to MP3');
  }
}

// Function to get supported audio formats
export async function getSupportedAudioFormats(): Promise<string[]> {
  try {
    const response = await fetch('/api/audio/formats');
    if (!response.ok) {
      throw new Error('Failed to fetch supported formats');
    }
    
    const data = await response.json();
    return data.supportedFormats;
  } catch (error) {
    console.error('Error fetching supported formats:', error);
    return [];
  }
}

// Function to play audio blob
export function playAudioBlob(audioBlob: Blob): Promise<void> {
  return new Promise((resolve, reject) => {
    const audio = new Audio();
    const url = URL.createObjectURL(audioBlob);
    
    audio.onloadeddata = () => {
      audio.play().then(resolve).catch(reject);
    };
    
    audio.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to play audio'));
    };
    
    audio.onended = () => {
      URL.revokeObjectURL(url);
    };
    
    audio.src = url;
  });
}

// Function to download audio blob
export function downloadAudioBlob(audioBlob: Blob, filename: string): void {
  const url = URL.createObjectURL(audioBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
} 