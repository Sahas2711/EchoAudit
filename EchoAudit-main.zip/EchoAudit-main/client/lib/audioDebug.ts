// Audio recording diagnostics utility

export interface BrowserSupport {
  hasMediaDevices: boolean;
  hasGetUserMedia: boolean;
  hasMediaRecorder: boolean;
  isHttps: boolean;
  supportedMimeTypes: string[];
  errorMessage?: string;
}

export function checkBrowserSupport(): BrowserSupport {
  const support: BrowserSupport = {
    hasMediaDevices: false,
    hasGetUserMedia: false,
    hasMediaRecorder: false,
    isHttps: location.protocol === 'https:' || location.hostname === 'localhost',
    supportedMimeTypes: [],
  };

  try {
    // Check MediaDevices API
    support.hasMediaDevices = !!navigator.mediaDevices;
    
    // Check getUserMedia
    support.hasGetUserMedia = !!navigator.mediaDevices?.getUserMedia;
    
    // Check MediaRecorder
    support.hasMediaRecorder = !!window.MediaRecorder;
    
    // Check supported MIME types
    if (support.hasMediaRecorder) {
      const mimeTypes = [
        'audio/webm;codecs=opus',
        'audio/webm',
        'audio/mp4',
        'audio/ogg;codecs=opus',
        'audio/wav',
      ];
      
      support.supportedMimeTypes = mimeTypes.filter(type => 
        MediaRecorder.isTypeSupported(type)
      );
    }
    
    // Generate error message if any issues
    const issues = [];
    if (!support.hasMediaDevices) issues.push('MediaDevices API not available');
    if (!support.hasGetUserMedia) issues.push('getUserMedia not available');
    if (!support.hasMediaRecorder) issues.push('MediaRecorder not available');
    if (!support.isHttps) issues.push('Requires HTTPS (except localhost)');
    if (support.supportedMimeTypes.length === 0) issues.push('No supported audio formats');
    
    if (issues.length > 0) {
      support.errorMessage = issues.join(', ');
    }
    
  } catch (error) {
    support.errorMessage = `Browser check failed: ${(error as Error).message}`;
  }
  
  return support;
}

export async function testMicrophoneAccess(): Promise<{
  success: boolean;
  error?: string;
  deviceInfo?: MediaDeviceInfo[];
}> {
  try {
    // Request microphone access
    const stream = await navigator.mediaDevices.getUserMedia({ 
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      }
    });
    
    // Get device information
    const devices = await navigator.mediaDevices.enumerateDevices();
    const audioInputs = devices.filter(device => device.kind === 'audioinput');
    
    // Test MediaRecorder creation
    const recorder = new MediaRecorder(stream);
    
    // Clean up
    stream.getTracks().forEach(track => track.stop());
    
    return {
      success: true,
      deviceInfo: audioInputs,
    };
  } catch (error) {
    let errorMessage = 'Unknown error';
    
    if (error instanceof DOMException) {
      switch (error.name) {
        case 'NotAllowedError':
          errorMessage = 'Microphone access denied by user';
          break;
        case 'NotFoundError':
          errorMessage = 'No microphone device found';
          break;
        case 'NotSupportedError':
          errorMessage = 'Microphone access not supported';
          break;
        case 'NotReadableError':
          errorMessage = 'Microphone is being used by another application';
          break;
        case 'OverconstrainedError':
          errorMessage = 'Microphone constraints cannot be satisfied';
          break;
        case 'SecurityError':
          errorMessage = 'Microphone access blocked by security policy';
          break;
        default:
          errorMessage = `Permission error: ${error.message}`;
      }
    } else {
      errorMessage = (error as Error).message;
    }
    
    return {
      success: false,
      error: errorMessage,
    };
  }
}

export function getBrowserInfo(): string {
  const ua = navigator.userAgent;
  let browser = 'Unknown';
  
  if (ua.includes('Chrome') && !ua.includes('Edg')) {
    browser = 'Chrome';
  } else if (ua.includes('Firefox')) {
    browser = 'Firefox';
  } else if (ua.includes('Safari') && !ua.includes('Chrome')) {
    browser = 'Safari';
  } else if (ua.includes('Edg')) {
    browser = 'Edge';
  }
  
  return `${browser} on ${navigator.platform}`;
} 