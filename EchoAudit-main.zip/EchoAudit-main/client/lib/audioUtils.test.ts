import { describe, it, expect, vi, beforeEach } from 'vitest';
import { WebAudioRecorder, convertAudioToMp3, playAudioBlob, downloadAudioBlob } from './audioUtils';

// Mock the Web Audio API
const mockMediaRecorder = {
  start: vi.fn(),
  stop: vi.fn(),
  pause: vi.fn(),
  resume: vi.fn(),
  state: 'inactive',
  ondataavailable: null,
  onstop: null,
};

global.MediaRecorder = vi.fn().mockImplementation(() => mockMediaRecorder) as any;
(global.MediaRecorder as any).isTypeSupported = vi.fn().mockReturnValue(true);

Object.defineProperty(global.navigator, 'mediaDevices', {
  value: {
    getUserMedia: vi.fn().mockResolvedValue({
      getTracks: () => [{ stop: vi.fn() }],
    }),
  },
  writable: true,
});

// Mock fetch
global.fetch = vi.fn();

// Mock URL.createObjectURL and URL.revokeObjectURL
global.URL.createObjectURL = vi.fn(() => 'mock-url');
global.URL.revokeObjectURL = vi.fn();

// Mock Audio
global.Audio = vi.fn().mockImplementation(() => ({
  play: vi.fn().mockResolvedValue(undefined),
  onloadeddata: null,
  onerror: null,
  onended: null,
  src: '',
}));

// Mock document
global.document = {
  createElement: vi.fn().mockImplementation((tag) => {
    if (tag === 'a') {
      return {
        href: '',
        download: '',
        click: vi.fn(),
      };
    }
    return {};
  }),
  body: {
    appendChild: vi.fn(),
    removeChild: vi.fn(),
  },
} as any;

describe('AudioUtils', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('WebAudioRecorder', () => {
    it('should create a new recorder instance', () => {
      const recorder = new WebAudioRecorder();
      expect(recorder).toBeInstanceOf(WebAudioRecorder);
    });

    it('should start recording', async () => {
      const recorder = new WebAudioRecorder();
      await recorder.start();
      
      expect(navigator.mediaDevices.getUserMedia).toHaveBeenCalledWith({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 44100,
        }
      });
    });

    it('should handle recording start errors', async () => {
      const recorder = new WebAudioRecorder();
      (navigator.mediaDevices.getUserMedia as any).mockRejectedValue(new Error('Permission denied'));
      
      await expect(recorder.start()).rejects.toThrow('Failed to start audio recording');
    });

    it('should handle stop recording when not recording', async () => {
      const recorder = new WebAudioRecorder();
      
      await expect(recorder.stop()).rejects.toThrow('No active recording');
    });

    it('should check if recording is active', () => {
      const recorder = new WebAudioRecorder();
      expect(recorder.isRecording()).toBe(false);
    });
  });

  describe('convertAudioToMp3', () => {
    it('should convert audio blob to MP3', async () => {
      const mockBlob = new Blob(['test'], { type: 'audio/webm' });
      const mockMp3Blob = new Blob(['mp3data'], { type: 'audio/mpeg' });
      
      (global.fetch as any).mockResolvedValue({
        ok: true,
        blob: vi.fn().mockResolvedValue(mockMp3Blob),
      });
      
      const result = await convertAudioToMp3(mockBlob);
      expect(result).toBeInstanceOf(Blob);
      expect(fetch).toHaveBeenCalledWith('/api/audio/convert', {
        method: 'POST',
        body: expect.any(FormData),
      });
    });

    it('should handle conversion errors', async () => {
      const mockBlob = new Blob(['test'], { type: 'audio/webm' });
      
      (global.fetch as any).mockResolvedValue({
        ok: false,
        json: vi.fn().mockResolvedValue({ error: 'Conversion failed' }),
      });
      
      await expect(convertAudioToMp3(mockBlob)).rejects.toThrow('Failed to convert audio to MP3');
    });
  });

  describe('playAudioBlob', () => {
    it('should play audio blob', async () => {
      const mockBlob = new Blob(['test'], { type: 'audio/mpeg' });
      const mockAudio = {
        play: vi.fn().mockResolvedValue(undefined),
        onloadeddata: null,
        onerror: null,
        onended: null,
        src: '',
      };
      
      (global.Audio as any).mockImplementation(() => mockAudio);
      
      const playPromise = playAudioBlob(mockBlob);
      
      // Simulate audio loaded
      mockAudio.onloadeddata();
      
      await playPromise;
      expect(mockAudio.play).toHaveBeenCalled();
    });
  });

  describe('downloadAudioBlob', () => {
    it('should download audio blob', () => {
      const mockBlob = new Blob(['test'], { type: 'audio/mpeg' });
      
      downloadAudioBlob(mockBlob, 'test.mp3');
      
      expect(document.createElement).toHaveBeenCalledWith('a');
      expect(URL.createObjectURL).toHaveBeenCalledWith(mockBlob);
      expect(URL.revokeObjectURL).toHaveBeenCalled();
    });
  });
}); 