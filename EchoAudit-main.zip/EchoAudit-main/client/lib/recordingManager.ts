// Recording Manager - Handles saving and managing audio recordings

export interface RecordingInfo {
  id: string;
  filename: string;
  size: number;
  type: string;
  duration?: number;
  timestamp: Date;
  blob: Blob;
}

export class RecordingManager {
  private recordings: RecordingInfo[] = [];
  private storageKey = 'echoaudit_recordings';

  constructor() {
    this.loadRecordings();
  }

  // Save a new recording
  async saveRecording(blob: Blob, filename?: string): Promise<RecordingInfo> {
    const id = this.generateId();
    const timestamp = new Date();
    const defaultFilename = `recording_${timestamp.getTime()}.webm`;
    const finalFilename = filename || defaultFilename;

    const recording: RecordingInfo = {
      id,
      filename: finalFilename,
      size: blob.size,
      type: blob.type,
      timestamp,
      blob
    };

    // Add to memory
    this.recordings.unshift(recording); // Add to beginning of array
    
    // Save to localStorage (for persistence)
    this.saveToStorage();
    
    // Save to server folder
    await this.saveToServerFolder(recording);
    
    console.log(`Recording saved: ${finalFilename} (${blob.size} bytes)`);
    return recording;
  }

  // Get all recordings from server
  async getRecordings(): Promise<RecordingInfo[]> {
    try {
      const response = await fetch('/api/recordings');
      if (response.ok) {
        const data = await response.json();
        return data.recordings.map((rec: any) => ({
          ...rec,
          timestamp: new Date(rec.timestamp),
          blob: new Blob() // Placeholder blob
        }));
      }
    } catch (error) {
      console.warn('Failed to fetch recordings from server:', error);
    }
    
    // Fallback to local recordings
    return [...this.recordings];
  }

  // Get a specific recording by ID
  getRecording(id: string): RecordingInfo | undefined {
    return this.recordings.find(rec => rec.id === id);
  }

  // Delete a recording
  async deleteRecording(id: string): Promise<boolean> {
    try {
      const response = await fetch(`/api/recordings/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        // Also remove from local storage
        const index = this.recordings.findIndex(rec => rec.id === id);
        if (index !== -1) {
          this.recordings.splice(index, 1);
          this.saveToStorage();
        }
        return true;
      }
    } catch (error) {
      console.warn('Failed to delete recording from server:', error);
    }
    
    return false;
  }

  // Download a recording
  downloadRecording(id: string): boolean {
    // Download from server
    const url = `/api/recordings/download/${id}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = id;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    return true;
  }

  // Play a recording
  playRecording(id: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const recording = this.getRecording(id);
      if (!recording) {
        reject(new Error('Recording not found'));
        return;
      }

      const url = URL.createObjectURL(recording.blob);
      const audio = new Audio(url);
      
      audio.onended = () => {
        URL.revokeObjectURL(url);
        resolve();
      };
      
      audio.onerror = () => {
        URL.revokeObjectURL(url);
        reject(new Error('Failed to play recording'));
      };
      
      audio.play().catch(reject);
    });
  }

  // Export all recordings as a zip file
  async exportAllRecordings(): Promise<void> {
    if (this.recordings.length === 0) {
      throw new Error('No recordings to export');
    }

    // For now, we'll just download them individually
    // In a real implementation, you'd use a library like JSZip
    console.log('Exporting all recordings...');
    
    for (const recording of this.recordings) {
      this.downloadRecording(recording.id);
      // Add a small delay between downloads
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  // Clear all recordings
  async clearAllRecordings(): Promise<void> {
    try {
      const response = await fetch('/api/recordings', {
        method: 'DELETE',
      });

      if (response.ok) {
        const result = await response.json();
        console.log(`Cleared ${result.deletedCount} recordings from server`);
      }
    } catch (error) {
      console.warn('Failed to clear recordings from server:', error);
    }
    
    // Also clear local storage
    this.recordings = [];
    this.saveToStorage();
    console.log('All recordings cleared');
  }

  // Get storage statistics
  async getStorageStats(): Promise<{ count: number; totalSize: number; averageSize: number; folderPath?: string }> {
    try {
      const response = await fetch('/api/recordings/stats');
      if (response.ok) {
        const stats = await response.json();
        return stats;
      }
    } catch (error) {
      console.warn('Failed to get stats from server:', error);
    }
    
    // Fallback to local stats
    const count = this.recordings.length;
    const totalSize = this.recordings.reduce((sum, rec) => sum + rec.size, 0);
    const averageSize = count > 0 ? totalSize / count : 0;

    return { count, totalSize, averageSize };
  }

  // Private methods
  private generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  private saveToStorage(): void {
    try {
      // Convert recordings to a storage-friendly format
      const storageData = this.recordings.map(rec => ({
        ...rec,
        blob: null, // Don't store blob in localStorage (too large)
        timestamp: rec.timestamp.toISOString()
      }));
      
      localStorage.setItem(this.storageKey, JSON.stringify(storageData));
    } catch (error) {
      console.warn('Failed to save recordings to localStorage:', error);
    }
  }

  private loadRecordings(): void {
    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        const data = JSON.parse(stored);
        // Note: We can't restore the actual blob data from localStorage
        // This is just for metadata persistence
        this.recordings = data.map((item: any) => ({
          ...item,
          timestamp: new Date(item.timestamp),
          blob: new Blob() // Placeholder blob
        }));
      }
    } catch (error) {
      console.warn('Failed to load recordings from localStorage:', error);
    }
  }

  private async saveToServerFolder(recording: RecordingInfo): Promise<void> {
    try {
      const formData = new FormData();
      formData.append('audio', recording.blob, recording.filename);

      const response = await fetch('/api/recordings/save', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        const result = await response.json();
        console.log(`Recording saved to server folder: ${result.recording.filename}`);
      } else {
        console.warn('Failed to save recording to server folder');
      }
    } catch (error) {
      console.warn('Error saving recording to server folder:', error);
    }
  }
}

// Global recording manager instance
export const recordingManager = new RecordingManager(); 